/* Generated from @oaktech/saas-ui 0.2.14; edit src/account-login-panel-view.ts or src/account-menu-behavior.ts. */
(function(){
"use strict";
/** Shared display-only structure for React and the native browser adapter. */
const accountSources = ["Casdoor", "Token", "邮箱验证码", "管理员 Token",
    "内置账号（历史兼容）", "本机使用（无外部认证）", "旧版登录"];
const element = (tag, attributes, ...children) => ({ tag, attributes, children });
function accountDetailsView({ headingLevel = 1, displayName, source, issuer, subject, localUserId, email, emailVerified, businessRole, currentAccess, tenant, workspace }, headingId) {
    const missing = source === "未登录" ? "未登录" : "未记录";
    const identityMissing = source === "管理员 Token" || source === "Token" ? `不适用（${source}）` : missing;
    const recorded = (value, fallback = missing) => typeof value === "string" ? (value.trim() ? value : fallback) : typeof value === "number" && Number.isFinite(value) ? value : fallback;
    const rows = [
        ["显示名称", recorded(displayName)], ["身份来源", source], ["身份签发方（Issuer）", recorded(issuer, identityMissing)],
        ["身份 ID（Subject）", recorded(subject, identityMissing)], ["本地用户编号", recorded(localUserId)], ["邮箱", recorded(email)],
        ["邮箱验证", typeof email === "string" && email.trim() && typeof emailVerified === "boolean" ? (emailVerified ? "已验证" : "未验证") : missing],
        ["普通业务角色", recorded(businessRole)], ["当前访问权限", recorded(currentAccess)],
        ["租户", typeof tenant === "string" && tenant.trim() ? tenant : undefined],
        ["工作空间", typeof workspace === "string" && workspace.trim() ? workspace : undefined],
    ];
    return element("section", { className: "oak-app-account-details", "data-slot": "oak-app-account-details", "aria-labelledby": headingId }, element(`h${headingLevel}`, { className: headingLevel === 1 ? "oak-app-page-title" : "oak-app-section-title", id: headingId }, "账号详情"), element("dl", { className: "oak-app-detail-list" }, ...rows.filter(([, value]) => value !== undefined && value !== "").map(([label, value]) => element("div", { className: "oak-app-detail-row" }, element("dt", {}, label), element("dd", {}, value)))));
}
function displayHref(value, fallback) {
    if (typeof value !== "string" || /[\u0000-\u0020\\]/.test(value))
        return fallback;
    if (/^\/(?!\/)/.test(value))
        return value;
    try {
        const url = new URL(value);
        if (["https:", "http:"].includes(url.protocol))
            return value;
    }
    catch { }
    return fallback;
}
function accountLoginPanelView(data, id, hasLogout = false) {
    const modes = { token: "访问密钥", casdoor: "Casdoor", "email-code": "邮箱验证码", legacy: "旧内置账号", unavailable: "登录配置不可用" };
    const states = { "signed-out": "未登录", "signed-in": "已登录", pending: "等待业务授权", unavailable: "暂时无法确认" };
    const suppliedState = Object.hasOwn(states, data.state) ? data.state : "unavailable";
    const account = data.account && typeof data.account === "object" && accountSources.some(source => source === data.account?.source) ? data.account : undefined;
    const state = (suppliedState === "signed-in" || suppliedState === "pending") && !account ? "unavailable" : suppliedState;
    const authenticated = state === "signed-in" || state === "pending";
    const actions = [];
    if (!authenticated)
        actions.push(element("a", { className: "oak-app-action oak-app-action--primary", href: displayHref(data.loginHref, "/login") }, "登录"));
    if (authenticated && hasLogout)
        actions.push(element("div", { className: "oak-app-account-login-logout", "data-slot": "oak-app-account-login-logout" }, { slot: "logout" }));
    actions.push(element("a", { className: "oak-app-action", href: displayHref(data.adminHref, "/settings/admin") }, "管理员入口"));
    const content = [
        element("h2", { className: "oak-app-section-title", id: `${id}-title` }, "登录方式与状态"),
        element("p", { className: "oak-app-account-login-description" }, "查看登录方式与会话状态。"),
        element("dl", { className: "oak-app-detail-list oak-app-account-login-summary" }, element("div", { className: "oak-app-detail-row" }, element("dt", {}, "登录方式"), element("dd", {}, Object.hasOwn(modes, data.loginMode) ? modes[data.loginMode] : modes.unavailable)), element("div", { className: "oak-app-detail-row" }, element("dt", {}, "登录状态"), element("dd", {}, states[state]))),
    ];
    if (state === "unavailable")
        content.push(element("p", { className: "oak-app-account-login-status", role: "status" }, "暂时无法确认登录状态，请稍后重试。"));
    content.push(element("div", { className: "oak-app-account-login-actions" }, ...actions));
    return element("section", { className: "oak-app-account-login", "data-slot": "oak-app-account-login", "aria-labelledby": `${id}-title` }, ...content);
}
const escapeDisplay = (value) => String(value).replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#x27;" })[character]);
function nativeAccountNode(node, slots) {
    if (typeof node === "string" || typeof node === "number")
        return escapeDisplay(node);
    if ("slot" in node)
        return slots[node.slot] ?? "";
    const attributes = Object.entries(node.attributes).map(([key, value]) => ` ${key === "className" ? "class" : key}="${escapeDisplay(value)}"`).join("");
    return `<${node.tag}${attributes}>${node.children.map(child => nativeAccountNode(child, slots)).join("")}</${node.tag}>`;
}
/** logoutHtml must be a fixed, host-owned logout button, never identity data or remote HTML. */
function renderAccountLoginPanel(data, { logoutHtml = "", id = "oak-account-login" } = {}) {
    return nativeAccountNode(accountLoginPanelView(data, id, Boolean(logoutHtml)), { logout: logoutHtml });
}
/** Native hosts use the same identity-only view as the React AccountDetails component. */
function renderAccountDetails(data, { id = "oak-account-details" } = {}) {
    return nativeAccountNode(accountDetailsView({ ...data, headingLevel: data.headingLevel ?? 2 }, id), {});
}
const categoryLabels = Object.freeze({
    account: "登录设置", admin: "管理员入口", application: "应用设置", about: "关于应用",
});
/** Hosts provide their actual routes, including query-based and standalone layouts. */
function settingsCategoryItems(hrefs, current, extras = []) {
    const keys = ["account", "admin", "application", "about"];
    return [...keys.map(key => ({ label: categoryLabels[key], href: displayHref(hrefs[key], "/settings"), current: key === current })),
        ...extras.map(item => ({ label: item.label, href: displayHref(item.href, "/settings"), current: item.current }))];
}
function settingsLayoutView({ title = "系统设置", items }) {
    return element("section", { className: "oak-app-settings", "data-slot": "oak-app-settings" }, element("h1", { className: "oak-app-page-title" }, title), element("div", { className: "oak-app-settings-body" }, element("nav", { className: "oak-app-settings-navigation", "data-slot": "oak-app-settings-navigation", "aria-label": "设置分类" }, ...items.map(item => element("a", {
        className: "oak-app-nav-link", href: displayHref(item.href, "/settings"),
        ...(item.current ? { "aria-current": "page" } : {}),
    }, item.label))), element("div", { className: "oak-app-settings-content", "data-slot": "oak-app-settings-content" }, { slot: "settings-content" })));
}
/** A fixed heading hierarchy and spacing; all application-specific controls remain host-owned. */
function settingsSectionView({ id, title, description, hasContent = false, hasActions = false }) {
    return element("section", {
        className: "oak-app-settings-section", "data-slot": "oak-app-settings-section",
        ...(id ? { id } : {}),
    }, element("h2", { className: "oak-app-section-title" }, title), ...(description ? [element("p", { className: "oak-app-section-description" }, description)] : []), ...(hasContent ? [element("div", { className: "oak-app-section-body", "data-slot": "oak-app-section-body" }, { slot: "settings-content" })] : []), ...(hasActions ? [element("div", { className: "oak-app-section-actions", "data-slot": "oak-app-section-actions" }, { slot: "settings-actions" })] : []));
}
/** Slot HTML must be built by the host from fixed markup with its own dynamic data escaped. */
function renderSettingsLayout(data, { contentHtml = "" } = {}) {
    return nativeAccountNode(settingsLayoutView(data), { "settings-content": contentHtml });
}
function renderSettingsSection(data, { contentHtml = "", actionsHtml = "" } = {}) {
    return nativeAccountNode(settingsSectionView({ ...data, hasContent: Boolean(contentHtml), hasActions: Boolean(actionsHtml) }), {
        "settings-content": contentHtml, "settings-actions": actionsHtml,
    });
}
function statusNoticeView({ message, tone = "neutral" }) {
    return element("p", { className: "oak-app-notice", "data-tone": tone, role: tone === "error" ? "alert" : "status" }, message);
}
function renderStatusNotice(data) {
    return nativeAccountNode(statusNoticeView(data), {});
}

/** A real modal shared by React portals and the native application adapter. */
function openAccountDialog(options) {
    return openSharedDialog(options);
}
/** The same dialog lifecycle, with an anchored desktop / compact mobile presentation. */
function openQuickAccessPanel(options) {
    return openSharedDialog(options, options.returnFocus);
}
function openSharedDialog({ document, title, content, returnFocus, onClose }, anchor) {
    const dialog = document.createElement("dialog");
    dialog.className = "oak-app-account-dialog";
    if (anchor)
        dialog.classList.add("oak-quick-access-panel");
    dialog.dataset.slot = "oak-app-account-dialog";
    dialog.setAttribute("aria-label", title);
    const heading = document.createElement("div");
    heading.className = "oak-app-account-dialog-header";
    const label = document.createElement("h2");
    label.className = "oak-app-account-dialog-title";
    label.textContent = title;
    const dismiss = document.createElement("button");
    dismiss.type = "button";
    dismiss.className = "oak-app-account-dialog-close";
    dismiss.setAttribute("aria-label", "关闭窗口");
    dismiss.textContent = "×";
    heading.append(label, dismiss);
    content.classList.add("oak-app-account-dialog-content");
    content.dataset.slot = "oak-app-account-dialog-content";
    dialog.append(heading, content);
    const previousOverflow = document.body.style.overflow;
    const previousPadding = document.body.style.paddingRight;
    const previousClientWidth = document.documentElement.clientWidth;
    const previousFocus = returnFocus ?? document.activeElement;
    let closed = false;
    const view = document.defaultView;
    const position = () => {
        if (!anchor || !view || !dialog.open)
            return;
        if (view.innerWidth < 1024) {
            dialog.style.removeProperty("left");
            dialog.style.removeProperty("top");
            return;
        }
        const trigger = anchor.getBoundingClientRect();
        const panel = dialog.getBoundingClientRect();
        dialog.style.left = Math.max(12, Math.min(trigger.right - panel.width, view.innerWidth - panel.width - 12)) + "px";
        dialog.style.top = Math.max(12, Math.min(trigger.bottom + 8, view.innerHeight - panel.height - 12)) + "px";
    };
    const outside = (event) => {
        if (!anchor || closed)
            return;
        const pointer = event;
        const box = dialog.getBoundingClientRect();
        const path = event.composedPath();
        if ((!path.includes(dialog) && !path.includes(anchor)) || (event.target === dialog && (pointer.clientX < box.left || pointer.clientX > box.right || pointer.clientY < box.top || pointer.clientY > box.bottom)))
            close();
    };
    const trapFocus = (event) => {
        if (event.key !== "Tab" || event.ctrlKey || event.altKey || event.metaKey)
            return;
        const controls = Array.from(dialog.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(node => node.getClientRects().length > 0);
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (!first || !last)
            return;
        if (!dialog.contains(document.activeElement) || (event.shiftKey ? document.activeElement === first : document.activeElement === last)) {
            event.preventDefault();
            (event.shiftKey ? last : first).focus();
        }
    };
    const close = () => {
        if (closed)
            return;
        closed = true;
        dialog.close();
        dialog.remove();
        document.removeEventListener("keydown", trapFocus, true);
        if (anchor) {
            document.removeEventListener("click", outside, true);
            view?.removeEventListener("resize", position);
            document.removeEventListener("scroll", position, true);
            document.body.style.paddingRight = previousPadding;
        }
        document.body.style.overflow = previousOverflow;
        onClose?.();
        if (previousFocus?.isConnected)
            previousFocus.focus({ preventScroll: true });
    };
    dismiss.addEventListener("click", close);
    dialog.addEventListener("cancel", event => { event.preventDefault(); close(); });
    dialog.addEventListener("click", event => {
        const box = dialog.getBoundingClientRect();
        if (event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom))
            close();
    });
    document.body.append(dialog);
    // Preserve the reading width when the floating surface locks the page scroll.
    if (anchor && view) {
        document.addEventListener("click", outside, true);
        view.addEventListener("resize", position);
        document.addEventListener("scroll", position, true);
    }
    document.body.style.overflow = "hidden";
    if (anchor && view) {
        // Stable root gutters can remain after locking body overflow: compensate only
        // the space actually released, rather than counting the original gutter twice.
        const releasedWidth = Math.max(0, document.documentElement.clientWidth - previousClientWidth);
        if (releasedWidth)
            document.body.style.paddingRight = (parseFloat(view.getComputedStyle(document.body).paddingRight) + releasedWidth) + "px";
    }
    document.addEventListener("keydown", trapFocus, true);
    dialog.showModal();
    position();
    dismiss.focus({ preventScroll: true });
    return close;
}
/** Shared account-menu dismissal for React and the native browser adapter. */
function bindAccountMenu(menu, options = {}) {
    const document = menu.ownerDocument;
    const outside = (event) => {
        if (menu.open && !event.composedPath().includes(menu))
            menu.open = false;
    };
    const escape = (event) => {
        if (event.key !== "Escape" || event.defaultPrevented || !menu.open)
            return;
        const restoreFocus = menu.contains(document.activeElement);
        menu.open = false;
        if (restoreFocus) {
            event.preventDefault();
            menu.querySelector("summary")?.focus();
        }
    };
    const openPanel = (event) => {
        const target = event.target;
        const button = target?.closest("[data-oak-account-panel]");
        const panel = button?.dataset.oakAccountPanel;
        if (!button || !menu.contains(button) || !options.openPanel || (panel !== "account" && panel !== "settings"))
            return;
        event.preventDefault();
        menu.open = false;
        options.openPanel(panel);
    };
    // Capture also observes outside events stopped by an application-owned control.
    document.addEventListener("pointerdown", outside, true);
    document.addEventListener("click", outside, true);
    document.addEventListener("keydown", escape);
    menu.addEventListener("click", openPanel);
    return () => {
        document.removeEventListener("pointerdown", outside, true);
        document.removeEventListener("click", outside, true);
        document.removeEventListener("keydown", escape);
        menu.removeEventListener("click", openPanel);
    };
}

globalThis.OakSaasUI=Object.freeze({version:"0.2.14",renderAccountDetails,renderAccountLoginPanel,renderSettingsLayout,renderSettingsSection,settingsCategoryItems,renderStatusNotice,bindAccountMenu,openAccountDialog,openQuickAccessPanel});
})();
