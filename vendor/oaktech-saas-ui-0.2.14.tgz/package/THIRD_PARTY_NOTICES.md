# 来源与第三方许可

Button 从本地 `logistics-profit` 仓库的已提交版本提取，来源 commit `1ed3e610b338f8a40a6b673441299e109c2c7933`，文件 `components/ui/button.tsx`。保留其 variant、size 和 asChild API，仅改为包内导入并增加 React client 声明。该组件和本包的 Input/Card/Dialog 结构沿用 shadcn/ui 的组件模式；保留下列上游 MIT 声明。

官方许可核验：2026-10-08，https://github.com/shadcn-ui/ui/blob/main/LICENSE.md 。此声明仅覆盖相应上游/衍生部分，不将 OakTech 自有代码、项目或业务代码声明为开源。依赖的独立许可由各 npm 包自身提供。

## shadcn/ui

MIT License

Copyright (c) 2023 shadcn

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
