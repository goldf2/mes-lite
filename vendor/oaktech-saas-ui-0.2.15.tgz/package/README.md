## 0.2.15：异步内容的常用面板定位

`QuickAccessPanel`与`openQuickAccessPanel`沿用同一dialog底座。锚定面板在异步内容增减后通过ResizeObserver重新计算视口内位置，关闭与卸载时断开观察。无ResizeObserver时保留原有打开/resize/scroll定位；账号面板默认呈现和公开API保持不变，不扩大React19/Node24整包支持声明。

共享源合成浏览器回归：先构建UI，再设置既有本地`PLAYWRIGHT_MODULE_PATH`和`ESBUILD_MODULE_PATH`运行`npm run check:quick-access`。脚本不下载依赖，阻止全部浏览器网络请求，仅使用合成内容；证据默认写`.local/quick-access-panel`。实际消费者仍须独立验证宿主适配。

## 2026-10-12 · UI0.2.13 / 模板0.1.17

账号详情与登录设置拆分正文：AccountDetails仅展示可信身份、角色和权限；AccountLoginPanel仅展示登录方式、会话状态及宿主原登录/退出和管理员入口，不再内嵌账号详情。account输入仍用于会话状态校验，不能移除。React与native同源，原生新增renderAccountDetails供云桥独立账号面板使用。模态交互、认证、数据和卷保持。APP-UI-001 1.2.5；五宿主升级和双机上线分别验收。

# @oaktech/saas-ui 0.2.11

## 用户菜单（0.2.11）

公共导航不再渲染独立设置齿轮。匿名和已登录均显示最右 `details[data-slot="oak-app-account"]`；匿名菜单内为宿主真实 `loginHref` 登录及 `settingsHref` 登录设置，已登录保持真实姓名、账号详情、登录设置和原退出动作。设置路由不变。

React 内部 `AccountMenu` 在 effect 中绑定共享 `bindAccountMenu`，监听 document 捕获阶段的 pointerdown/click，菜单外页面/其他导航即使阻止冒泡也会收起；菜单内部不被干扰。Esc 收起并仅在原焦点位于菜单内时恢复 summary 焦点。卸载清理监听，不对业务折叠内容生效。

原生宿主从同一个固定 tgz 提取现有两资产，并在真实 details 节点上调用一次 `const cleanup = OakSaasUI.bindAccountMenu(detailsElement)`；移除节点前可调用 cleanup。匿名不隐藏整个用户菜单，按真实状态显示菜单条目。不要在宿主复制收起算法。`scripts/check-account-menu.mjs` 使用真实共享 SSR、原生共享行为和 Chromium 验证 1440/390/320px 两种状态；设置 `PLAYWRIGHT_MODULE_PATH` 和可选 `ACCOUNT_MENU_CHECK_OUTPUT` 后执行。

下文较早版本记录保留，齿轮及匿名直达登录的旧描述由本节替代。

UI 0.2.7 只修复宿主全局 CSS 对公共账号与系统设置详情字段 `dt/dd` 的覆盖。跨站统一字段标签14px、字段值16px、边距0与行高1.6；不影响任何业务数据字段的全局字体。规范见 APP-UI-001 v1.1.1。

独立 React 19 UI 包：shadcn 风格、Radix 交互原语、Tailwind CSS 4 和 Lucide 图标。只处理展示与交互，不依赖 Next.js、门户、Casdoor、租户、注册、支付或订阅。业务和数据由消费应用负责。

## 0.2.9 紧凑顶部栏（APP-UI-001 v1.2.1）

公共顶部栏统一默认52px内容高度（加1px底线），Logo大小36px，触控目标44×44px，固定右侧应用导航和系统设置图标与圆形用户头像。默认**不显示“应用工作台/某应用”两行品牌**，也不自动生成“业务工作台”菜单。业务及顶栏的导航内容由宿主通过`navigation`显式传入；若为空，完全不渲染该`nav`。

```tsx
<ApplicationFrame appName="企业地图" appMark={<img src="/logo.svg" alt="" />} appVersion="0.3.160"
  brandDisplay="logo" portalHref="https://saas.oaktechz.com/apps.html"
  navigation={[] /* 由业务页面自己选择 */}
  account={session ? {label: session.name, detail: session.source} : undefined}
  loginHref="/login" logoutAction={hostLogoutAction}>
  {children}
</ApplicationFrame>
```

`brandDisplay`为`auto`（默认：有Logo则Logo-only，无Logo退回文字品牌）、`logo`（若没有Logo仍安全退回文字）、`full`（明确选择 Logo+名称）。`appName`继续提供可访问名称、页脚及业务标识，`platformName`只在显式`full`模式用于顶部文案；不再强行放进紧凑顶部栏。账户操作仍由宿主安全地处理；图标链接只有外观变化，不改变目标/权限/退出语义。云桥原生HTML使用相同类名和同一CSS，业务菜单留在业务应用自定义侧栏。

## 单行业务头部插槽（0.2.10）

`ApplicationFrame` 支持可选 `headerTools={<BusinessToolbar/>}`：把真实业务导航/工具放在紧凑 Header 的中央一行。没有传值时仍保留 `navigation` 或留空。`headerTools` 不读取会话/权限，业务端负责认证上下文与内容、移动端工具收纳和退出前离开保护；不渲染独立公司/工作空间行。

```tsx
<ApplicationFrame appName="企业地图" appVersion="0.3.161"
  appMark={<img src="/brand/logo.png" alt="" />} headerTools={<MyBusinessTools/>}>
  <MyWorkbench />
</ApplicationFrame>
```

该插槽属于**公共框架能力**，不强制其他四站展示工作台工具。APP-UI-001 v1.2.2。

## 共享设计配置（0.2.8，APP-UI-001 v1.2.0）

只有这一份 `framework.css` 的 `:root { --oak-ui-* }` 设计变量表管理所有**非业务**UI的字体、字号、行高、字重、颜色、间距、圆角和尺寸。React组件消费固定的 `@oaktech/saas-ui/framework.css`；非React的云桥直接从同一个tgz提取 `framework.css`。二者必须来自完全相同的SHA256制品，不要复制变量表在五个宿主各维护一份。

核心字体变量包括 `--oak-ui-font-family`、`--oak-ui-font-size-brand/small/body/section/page/page-mobile`、`--oak-ui-font-size-settings-menu`、`--oak-ui-font-size-detail-label/detail-value`、`--oak-ui-font-weight-normal/medium/semibold`、`--oak-ui-line-height-body`。交互颜色使用 `--oak-ui-color-*`，公共布局、间距、边框等使用 `--oak-ui-space-*`、`--oak-ui-radius-*` 和 `--oak-ui-control-min-height`。

| 公共元素 | 设计变量 | 计算值（默认） |
|---|---|---|
| 品牌标题 | `--oak-ui-font-size-brand` | 18px |
| 设置页面标题 | `--oak-ui-font-size-page` | 28px |
| 手机设置标题 | `--oak-ui-font-size-page-mobile` | 24px |
| 设置分类菜单 | `--oak-ui-font-size-settings-menu` | 16px |
| 章节标题 | `--oak-ui-font-size-section` | 20px |
| 正文/操作按钮 | `--oak-ui-font-size-body/control` | 16px |
| 信息字段标签 | `--oak-ui-font-size-detail-label` | 14px |
| 信息字段值 | `--oak-ui-font-size-detail-value` | 16px |
| 普通触控高度 | `--oak-ui-control-min-height` | 44px |

公共样式不执行全局body重置，不要求业务地图/表格/维修记录遵循同一业务字号。框架用 `var(--oak-ui-*)` 而不依赖宿主全局样式；宿主不得单独重写 `.oak-app-*` 公共控件样式或把公共变量改成与其他站不一致。如确需调整平台级字体或主题，必须在共享源提交新版本并让五站固定升级、重做 computed-style 验收。

## 公共非业务界面层（0.2.6）

新的统一范围不止账号：导航容器/业务侧栏容器、系统设置四分类、登录与退出状态、账号、管理员入口、通用章节/状态反馈、版本页脚和移动布局都遵守 APP-UI-001 v1.1.0，**不要求不同应用菜单数量或业务内容完全相同**。统一设计只涉及表现，业务/认证/权限/会话在宿主。

```tsx
import {ApplicationFrame, SettingsLayout, SettingsSection, StatusNotice} from '@oaktech/saas-ui';
import {settingsCategoryItems} from '@oaktech/saas-ui/settings-model';
const hrefs = { account:'/settings', admin:'/settings/admin', application:'/settings/application', about:'/settings/about' };
<SettingsLayout items={settingsCategoryItems(hrefs,'admin')}>
  <SettingsSection title="管理员入口" description="使用本应用的实际管理方式。"
    actions={<a className="oak-app-action" href="/admin-login">独立超管登录</a>}>
    <StatusNotice message="请先登录。" />
  </SettingsSection>
</SettingsLayout>
```

**Next.js 服务端安全说明：** `settingsCategoryItems` 应从无 `use client` 的 `@oaktech/saas-ui/settings-model` 子路径导入，不能从包含交互组件的主入口直接在 Server Component 里调用。其他确有实际页面的分类通过 `settingsCategoryItems(hrefs, current, extras)` 附加在四类之后。CloudBridge 在同版固定包生成的 `native/account-login-panel.js` 中调用 `OakSaasUI.settingsCategoryItems/renderSettingsLayout/renderSettingsSection/renderStatusNotice`，并加载同版 `framework.css`。原生 `contentHtml/actionsHtml` 必须是宿主已正确转义的固定 HTML 片段；所有公共导航标签、URL、状态文字由共享源序列化。框架不可解释登录模式、创建工作空间或绕过权限。

## 账号与登录同源面板（0.2.5）

五个应用的公开 `/settings` 账号区使用唯一 `AccountLoginPanel`，不再由宿主自行拼装表格或管理员表单。固定 h2「账号与登录」、说明「查看当前登录状态与账号信息。」、摘要「登录方式 / 登录状态」；匿名仅显示「登录」「管理员入口」，已登录和等待授权才显示可信账号详情、宿主原退出控件及管理员入口；不可确认时仅通知，不展示身份。管理员凭据表单仅在 `/settings/admin` 或宿主实际兼容恢复页中。

```tsx
import { AccountLoginPanel } from '@oaktech/saas-ui';
<AccountLoginPanel loginMode="token" state="signed-out"
  loginHref="/login" adminHref="/settings/admin" />
// 已登录时：account 为真实 AccountDetailsProps（不含 headingLevel）；
// logoutAction 为宿主原有表单或登出按钮，组件不自行发起退出请求。
```

`loginMode`：`token | casdoor | email-code | legacy | unavailable`；`state`：`signed-out | signed-in | pending | unavailable`。未知身份字段显示「未记录」，Token 不伪造 Casdoor Issuer/Subject，身份以真实 issuer+subject 等宿主稳定值区分；相同邮箱不合并账号。内置历史账号、纯本机账号和旧版登录使用独立来源文字，不改认证算法或权限。

原生 Python/HTML 消费者从**同一固定 tgz** 取 `framework.css` 与 `native/account-login-panel.js`，加载后调用 `globalThis.OakSaasUI.renderAccountLoginPanel(props, {logoutHtml})`。`logoutHtml` 只允许宿主固定静态登出控件，不得拼接身份、远程 HTML 或其他用户输入；普通身份和链接内容由公共源转义。原生 JS 由 `src/account-login-panel-view.ts` 编译生成，不在宿主或 `native/` 手工改文案与结构。

当前 0.2.5 的自动生成范围**仅账号面板**；访问卡、导航与其他原生适配仍由 CloudBridge 薄适配层负责，不能把账号同源说成全部原生界面已迁源。测试含 React/原生 5×4 状态一致性、身份转义和原退出控件保留；完整生产可用性须由各宿主分别验收。

## 完整工作台框架

采用 [APP-UI-001 1.0.5](https://github.com/goldf2/saas-app-template/blob/feat/shared-ui-library-20261008/docs/APPLICATION_FRAMEWORK.md)。总览和五个业务模块使用同一套平台导航、账号菜单、系统设置、账号详情及页脚，主内容由模块提供。新增框架使用独立作用域CSS，不要求宿主升级Tailwind或替换认证库：

```tsx
import { ApplicationFrame, AccessCard, SettingsLayout, AccountLoginPanel, AccountDetails } from '@oaktech/saas-ui';
import '@oaktech/saas-ui/framework.css';

<ApplicationFrame
  platformName="应用工作台"
  appName="运账"
  appVersion={actualAppVersion}
  homeHref={overviewUrl}
  portalHref={overviewUrl}
  navigation={appBusinessLinks}
  account={identity ? {label: identity.displayName, href: '/account'} : undefined}
  logoutAction={actualLogoutForm}
>
  {/* 当前模块提供页面标题、业务菜单、API状态和主内容 */}
</ApplicationFrame>
```

`platformName` 由统一配置提供；单独运行时可省略，默认本应用名称。`navigation` 为 `{label,href,current?}[]`，两种模式均传本应用业务入口；目录通过portalHref提供，复杂业务菜单可放 `sidebar` 或主内容。`context` 是实际采用的租户/空间范围区域，单人应用可省略。`layout` 为 `content/wide/access`，分别用于常规页面、地图/宽表、认证状态。公共壳提供唯一main、跳到内容、常驻系统设置与页脚；宿主不再套完整AuthFrame或另一个AppShell。

`AccessCard` 统一Token登录、失败、退出、等待授权等卡片，接受 `appName/title/description/children/actions`；可选 `introduction={label,title,description,mark,highlights}` 统一品牌介绍，桌面双栏、手机单栏；未提供时保留紧凑卡片。真实表单和认证提交由宿主提供；正常Casdoor登录仍直接起跳。`SettingsLayout` 接受分组 `{label,href,current?}[]` 和内容，按规范固定账号与登录、管理员入口、应用设置、关于四组。

### 账号与登录（0.2.5）

`AccountLoginPanel`拥有完整账号设置内容：h2“账号与登录”、说明“查看当前登录状态与账号信息。”、“登录方式 / 登录状态”两行摘要、真实身份或不可确认通知及统一动作。宿主只负责可信状态映射与原操作，不自定义这部分文案或重复拼接管理员区。

```tsx
<AccountLoginPanel
  loginMode={trustedLoginMode}
  state={trustedAccountState}
  account={trustedAccount}
  loginHref="/login"
  adminHref="/settings/admin"
  logoutAction={originalLogoutAction}
/>
```

| 参数 | 含义 |
| --- | --- |
| `loginMode` | `token / casdoor / email-code / legacy / unavailable`，来自宿主已确认的普通登录方式；只是展示，不切换部署模式 |
| `state` | `signed-out / signed-in / pending / unavailable`；pending仅用于已有可信业务授权结论 |
| `account` | `Omit<AccountDetailsProps, 'headingLevel'>`，宿主验证后的真实身份、权限与范围；匿名/不可确认时不显示 |
| `loginHref / adminHref` | 原普通登录和管理员设置入口；危险协议及无效URL回退到 `/login` 与 `/settings/admin` |
| `logoutAction` | ReactNode，宿主原退出表单/组件；保留POST、CSRF、未保存保护及Casdoor退出语义 |

未登录只显示主按钮“登录”和次按钮“管理员入口”，不产生空身份表、管理员折叠框或Token输入。已登录/等待业务授权显示详情、原退出操作和管理员入口。不可确认统一显示“暂时无法确认登录状态，请稍后重试。”；未知状态或已登录但缺少合法账号来源同样降级，不推断账号。合法Token身份允许缺少外部issuer/subject/email；缺失值显示未记录，外部身份字段显示不适用。

账号来源精确区分`Casdoor / Token / 管理员 Token / 邮箱验证码 / 内置账号（历史兼容） / 本机使用（无外部认证） / 旧版登录`。APP_ADMIN_TOKEN或admin_token_root会话必须由宿主映射为“管理员 Token”，不能因为登录方式摘要“访问密钥”而标为个人Token。basic/builtin兼容后端不能标成邮箱验证码。邮箱验证只接受明确boolean，null/未知/字符串均显示未记录。名称/邮箱不代替issuer+subject，缺失值不生成用户编号、权限、租户或工作空间。

管理员表单位于 `/settings/admin`，宿主原 `/admin-login` 恢复入口保留。账号设置统一使用ApplicationFrame的content布局；这不改变业务地图/宽表布局或服务端权限。

#### 同源原生适配

唯一结构为 `src/account-login-panel-view.ts`。React adapter据此创建元素；`npm run build`先用tsc编译，再由 `scripts/build-native.mjs`生成无React依赖的 `native/account-login-panel.js`。两种输出共享文案、状态、字段顺序、CSS类与转义规则。构建产物包含版本，禁止在宿主直接修改。

CloudBridge从同一固定tgz提取 `framework.css` 与 `native/account-login-panel.js`，随自身版本部署并在manifest中记录共享版本、sourceCommit及两资产SHA256。先加载原生脚本，再渲染：

```js
const html = globalThis.OakSaasUI.renderAccountLoginPanel(trustedAccountDto, {
  logoutHtml: '<button type="button" id="host-logout">退出登录</button>'
});
accountContainer.innerHTML = html;
// 把固定按钮接回宿主原退出处理；不在此复制认证或CSRF逻辑。
```

`trustedAccountDto`与React参数一致，但不含logoutAction。`logoutHtml`是唯一不经转义的插槽，只允许固定宿主按钮，禁止拼入任何身份、URL或远程HTML；身份文本和链接属性一律经共享序列化器转义。未登录及不可确认状态不渲染退出插槽。原生IIFE在 `globalThis.OakSaasUI`暴露`version`和`renderAccountLoginPanel`；此版本只统一账号面板，其余原生外壳仍须单独检查。

### 匿名首页公开概览（0.2.4）

`AnonymousOverview` 接收 `appName`、可选 `description` 及 `features: readonly {title, description?, icon?}[]`，只展示公开模块简介和功能卡片，不提供业务列表、统计或账号插槽。宿主匿名根路由 `/` 在查询受保护业务数据之前返回此组件，使用 ApplicationFrame 的普通 content 布局；右上角 `loginHref="/login"` 提供显式登录。`/login` 才渲染 AccessCard 或按已配置 Casdoor 模式起跳。业务接口及其他受保护路由仍由宿主鉴权，公开功能介绍不能当作已登录业务。

```tsx
<ApplicationFrame appName={appName} appVersion={version} loginHref="/login">
  <AnonymousOverview appName={appName} description={publicDescription}
    features={[{title: '功能名称', description: '公开用途说明'}]} />
</ApplicationFrame>
```

原生HTML适配器使用相同 `.oak-app-overview`、`-intro`、`-title`、`-description`、`-features`、`-feature`、`-feature-title`、`-feature-description` 结构及同版CSS。文案使用宿主公开配置，不访问真实任务、客户、设备、网盘或账户。

### 登录表单视觉契约（0.2.4）

普通Token卡片固定标题“登录”、说明“请输入本应用的访问密钥。”、字段“访问密钥”及提交“登录”。普通登录右栏只显示标题、说明与表单，不显示眉题或重复的系统设置动作；系统设置固定在 ApplicationFrame 顶栏。AccessCard仍允许宿主对失败、退出等状态显式传 actions，不自动添加动作。真实endpoint、hidden/CSRF、pending、错误与disabled仍由宿主提供。

```tsx
<AccessCard appName={appName} title="登录" description="请输入本应用的访问密钥。"
  introduction={moduleIntroduction}
  >
  <div className="oak-app-access-form">
    {/* 原AdminTokenForm或form.oak-auth-form保持原提交与验证 */}
    {actualTokenForm}
  </div>
</AccessCard>
```

也可直接在真实form上加同名class，原生HTML适配器消费同版CSS。外包div不增加第二层grid/gap；内部form/fieldset无边框/内外距，grid gap16。label14px/550、grid gap8；可见文本/密码输入及submit为16px和48px高，输入圆角8px、内距11px 12px。checkbox/radio/hidden保留原语义和尺寸。主提交蓝色/550，normal无宿主阴影或位移，键盘焦点3px/offset3；role=alert统一14px红色和零margin/装饰，不覆盖hidden或限制长文本高度。

桌面双栏右面板padding48、min-height520，从顶部对齐；右侧不渲染眉题；说明16px/400，显式line-height1.6和padding0，避免宿主旧p行高污染位置；说明margin0，内容和动作各自与前一区域间隔24。空children不生成额外内容区，左侧标题继承介绍区文字颜色。移动断点继续采用既有单栏与较小padding。业务表单没有加这个class时不受影响。

`AccountDetails` 接收可信身份映射的名称、source、issuer、subject、本地编号、邮箱及验证状态、businessRole和currentAccess。来源明确区分Casdoor、普通Token、管理员Token和邮箱验证码；邮箱来源只是展示能力，发信与验证须接入真实认证模块。普通角色与临时管理员权限分别展示；tenant/workspace有真实值才显示。固定字段缺失显示未记录；Token不伪造Casdoor身份。独立嵌入使用 `headingLevel={2|3}`，独立账号页默认h1；AccountLoginPanel中的详情固定h3。

账号菜单使用原生details并包含账号详情、系统设置和宿主传入的退出操作，不推导退出路由或管理员资格。`appVersion` 必须来自当前应用真实版本；helpHref/privacyHref只有存在真实页面时才传入。footer始终在文档流内，不能遮挡业务。

CloudBridge等非React消费者从同版tgz取 `framework.css`，用服务端自动转义/安全DOM的薄HTML adapter生成同样的class和landmark结构。不得复制修改CSS，也不能把网盘账号当作登录用户。认证、CSRF和权限仍由宿主执行。

在规范源仓库运行参考页面生成与服务命令：

```sh
npm run reference:ui
python3 -m http.server 4318 --bind 127.0.0.1 --directory .local/framework-reference
```

参考页面在 `.local/framework-reference/index.html`，由本包真实组件生成，覆盖五模块与15类页面状态，并可切换组合/独立显示，仅使用合成身份，不执行真实登录。独立消费者仍须记录真实Token/Casdoor、退出、业务和手机验收。

## 固定制品与运行时验证

0.2.5新增AccountLoginPanel、同源原生IIFE及准确账号来源展示，消费固定新制品 `vendor/oaktech-saas-ui-0.2.5.tgz`。先核验并提交来源，再打包记录sourceCommit；包内两个原生资产必须与manifest摘要一致。所有旧制品保持不变，来源验证不表示五宿主已经安装或上线。

历史0.2.4：0.2.4 修正可见输入基础规则的 CSS 优先级，真实 cascade 下提交按钮恢复蓝底白字；移除访问卡右栏眉题，增加 AnonymousOverview。保持 `oak-app-access-form` 视觉作用域、认证提交、CSRF、字段和禁用语义。发布新制品 `vendor/oaktech-saas-ui-0.2.4.tgz`，已固化的0.2.2/0.2.3包保持不变。来源检查不代表五消费者已安装或上线，按接入表记录实际版本。

包元数据目前声明 Node `>=24`。历史UI0.2.2企业地图在 Node **22.23.3** 上实测该固定包的模块加载、SSR、572项宿主测试、类型检查和生产构建通过；这是该宿主及该版本的兼容证据，不将声明自动改为支持所有 Node 22。后续发布须核对并修正引擎声明，本轮保持固定制品不变。来源模板使用 Node >=24。

## 在独立仓库接入

在规范源仓库生成新的版本包，不覆盖已交付的旧版本：

```sh
npm ci
npm run pack:ui
```

将 `vendor/oaktech-saas-ui-0.2.5.tgz` 交付给消费仓库，保留在消费仓库自己的 `vendor/` 目录，并安装、提交 `package.json` 和 lockfile：

```sh
npm install --save-exact ./vendor/oaktech-saas-ui-0.2.5.tgz
```

消费方需要 React / React DOM 19。旧基础控件使用 Tailwind CSS 4；新增完整应用外壳的 framework.css 无需 Tailwind 编译。包内已编译 ESM JS 和类型声明，不需要 Next.js `transpilePackages` 或源码路径 alias。React 交互入口保留 `use client`。

消费应用的全局 CSS 引入：

```css
@import "tailwindcss";
@import "@oaktech/saas-ui/styles.css";

/* 可选：在公共主题之后覆盖品牌变量 */
:root {
  --primary: oklch(0.45 0.12 255);
}
```

已有复杂全局样式的应用，可使用 Tailwind 的独立 theme/utilities 入口并保留自己的 reset：

```css
@layer theme, base, components, utilities;
@import "tailwindcss/theme.css" layer(theme);
@import "tailwindcss/utilities.css" layer(utilities);
@import "@oaktech/saas-ui/styles.css";
```

`styles.css` 定义语义颜色和圆角、默认浅色主题、`.dark` 深色主题及 `@source "./dist"`。无 body 样式、preflight 或全局元素 reset。Tailwind 由宿主编译；`@source` 让跨仓安装后的组件类名被扫描，不能删除。消费方的 `header`、`button`、`input` 等旧全局规则应排除带 `data-slot` 的公共组件；`p`、`h1/h2`、`a` 等全局排版还应排除共享外壳、AccessCard、设置和账号组件的后代，防止覆盖介绍区颜色、字号和焦点样式。

## 空项目模板与认证边界

来源根模板0.1.9已经使用此包的完整外壳、四组设置和空业务插槽，详情见 [EMPTY_PROJECT_TEMPLATE](../../docs/EMPTY_PROJECT_TEMPLATE.md)。它包含真实 Casdoor OIDC 与中央授权后端；普通 Token、独立管理员恢复和邮箱验证码需要真实认证适配器，尚未实现。不能只填写 `APP_LOGIN_MODE` 或展示占位表单就宣称登录可用。五个已有消费者的 Token/Casdoor 后端分别保留和验收，公共 UI 不强制统一后端授权模型。

`APP_DISPLAY_MODE`、`APP_PLATFORM_NAME`、`APP_PORTAL_URL` 由宿主读取，再传给展示组件。公共包不读取环境变量，也不会由展示模式授予管理员、租户或工作空间访问。

## 组件接口

```tsx
import {
  Button, Input, Textarea, NativeSelect, AppShell,
  Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter,
  PageHeader,
  Dialog, DialogRoot, DialogTrigger, DialogContent,
  DialogTitle, DialogDescription, DialogHeader, DialogFooter, DialogClose,
  cn,
} from "@oaktech/saas-ui";
```

- `Button` 延续运账已使用的 `variant` 和 `size`：`default/destructive/outline/secondary/ghost/link`；`default/inline/compact/sm/lg/icon`。`asChild` 可包住 `<a>` 或消费应用的路由 Link。表单中显式设置 `type`；与原生 button 相同，省略时遵循浏览器默认提交规则。图标按钮需要可访问名称。
- `Input` 传递标准输入属性和 ref；`required`、`disabled`、`aria-invalid`、label 关联由应用设置。组件不内置业务校验。
- `Textarea` 同样传递原生 textarea 属性和 ref，支持多行值、`rows/maxLength` 与原生 FormData；`NativeSelect` 保留 select/option/optgroup 与 `name/required/multiple`，无需将现有表单改为 Radix Select 的受控状态。
- `Card` 系列提供布局；`CardTitle` 为 h3。`PageHeader` 使用 header + h1，支持 `title/description/eyebrow/actions` 与 `headingLevel={2|3}`，保持页面标题层级。
- `Dialog` 与 `DialogRoot` 都是 Radix Root，接受 `open/onOpenChange`。`DialogContent` 支持 `size="sm|md|lg"`、`dismissible`、`showCloseButton` 和 `closeLabel`。Root 和 Trigger 由消费应用组合。每个弹窗提供 `DialogTitle` 与 `DialogDescription`，若有意省略描述，显式传递 `aria-describedby={undefined}`。

保存过程中由消费应用传入 busy 状态：

```tsx
<Dialog open={open} onOpenChange={setOpen}>
  <DialogContent size="md" dismissible={!busy} aria-busy={busy}>
    <DialogHeader>
      <DialogTitle>新增客户</DialogTitle>
      <DialogDescription>填写客户名称和联系人。</DialogDescription>
    </DialogHeader>
    {/* 业务表单由应用提供 */}
    <DialogFooter>
      <DialogClose asChild>
        <Button type="button" variant="outline" disabled={busy}>取消</Button>
      </DialogClose>
      <Button type="submit" form="customer-form" disabled={busy}>保存</Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

`dismissible={false}` 会阻止 Escape、点击/焦点移动到外部关闭，并禁用默认关闭按钮。应用自建 `DialogClose`、取消按钮及 `onOpenChange` 同样应遵守 busy 状态。Radix 负责 focus trap、关闭后恢复焦点和 ARIA；实际键盘、外部点击、移动显示需要消费应用页面验证。

## 统一应用外壳

`AppShell` 提供响应式页头、品牌、导航、main、页脚和键盘跳转链接。只包含 UI；不决定身份、注册、菜单权限、独立域名或门户入口。导航和品牌可由宿主使用自己的路由 Link 或原生 a 提供。

```tsx
<AppShell
  brand={<a href="/">设备维修记录</a>}
  navigation={<>
    <Button asChild variant="ghost" size="sm"><a href="/records">记录</a></Button>
    <Button asChild variant="ghost" size="sm"><a href="/settings">设置</a></Button>
  </>}
  footer={<><span>设备维修记录</span><span>v0.1.0</span></>}
>
  <PageHeader title="维修记录" description="登记与查看设备检修情况。" />
  {/* 原业务页面 */}
</AppShell>
```

组件自身包住 header/nav/main/footer，`navigation` 与 `footer` 传内容片段，不再嵌套同类 landmark。`mainId` 默认 `main-content`，与 skip link 对应；`skipLabel` 默认“跳到内容”，`navigationLabel` 默认“主导航”。`mainClassName` 可调整业务内容宽度和间距，`className` 作用于外壳。

固定 `data-slot`：`app-shell/app-skip-link/app-header/app-header-content/app-brand/app-navigation/app-main/app-footer/app-footer-content`。宿主原来的全局 header/main/footer/nav 元素规则应排除这些 slots，保持公共布局。AppShell 显式设置字体、颜色、背景、边框、间距和盒模型，不要求宿主开启 Tailwind preflight。可以覆盖 `--saas-font-family` 以加载自有字体。AppShell 会为子控件提供一致字体；控件本身也使用继承字体和显式边框。

## 维护与交付

```sh
npm run build:ui
npm test
npm run pack:ui
```

另可使用已安装Playwright运行 `node scripts/check-access-form-visual.mjs <playwright-module-path>`。该脚本在独立Chromium中拦截全部网络，验证真实computed按钮蓝/白、hover、focus、error、hidden、pending、业务控件及匿名概览；无新应用依赖、真实凭据或生产操作。

基础测试验证原生表单属性、select 选中值、textarea 多行值、asChild 链接、标题语义与 AppShell skip link/main 关联；不会代替浏览器中的 Dialog 行为或视觉验收。包使用 `tsc` 编译，无额外 bundler；发布包只包含 dist、原生生成资产、样式、README、来源声明和 package.json。原生IIFE显式声明sideEffects，防止被消费方打包器错误移除。

只在本包修改公共组件、补充来源和验证后提升包版本，再让应用逐个升级。避免消费方直接修改 node_modules 或复制另一个组件配方。应用独立发布、注册和计费；公共 UI 包不决定这些业务。

上游参考：[shadcn/ui](https://ui.shadcn.com/docs)、[Radix Dialog](https://www.radix-ui.com/primitives/docs/components/dialog)、[Tailwind CSS](https://tailwindcss.com/docs)。来源声明见 THIRD_PARTY_NOTICES.md。该私有包的自有代码未声明开放许可；shadcn 衍生部分继续遵循其 MIT 声明。


## UI0.2.14：主页两列组合与常用浮层

在既有应用壳内使用`.oak-workspace-home`、`.oak-workspace-home-nav`、`.oak-workspace-home-main`组合首页。该样式在1024px起使用220px导航与minmax(0,1fr)主区；它不输出新header/main或改其他领域布局。

React宿主从根导入`QuickAccessPanel`，提供`label?`、`title?`、`count?`和`children`，并引入`framework.css`。组件不取业务数据、不统计使用、不生成权限或收藏记录。

非整包消费方可从同一固定TGZ提取`framework.css`及`native/panel-behavior.js`、`.d.ts`，调用`openQuickAccessPanel({document,title,content,returnFocus,onClose?})`，返回幂等关闭函数。内容先渲染到传入的HTMLElement，再调用；卸载时关闭。公共源负责原生dialog、定位、捕获外点点击、Escape、关闭按钮、焦点返回及滚动恢复。宿主只适配真实内容与React portal。生成资产禁止手改，版本、来源提交和文件摘要须记录。该浏览器资产子集可由Node20宿主服务，不表示整包peer/engines放宽。
