import type {ReactElement} from 'react';
export function AdminTokenForm(props:{endpoint:string;next?:string;title?:string;description?:string;buttonLabel?:string;tokenLabel?:string;placeholder?:string;embedded?:boolean}):ReactElement;
export function AdminModePanel(props:{endpoint?:string;exitEndpoint?:string;elevated?:boolean;next?:string;title?:string}):ReactElement;
export const DeveloperTokenForm:typeof AdminTokenForm;
export function CasdoorConfigPanel(props:{endpoint:string;title?:string;returnHref?:string;embedded?:boolean}):ReactElement;
