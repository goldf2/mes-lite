export { AuthError, modeFromEnv } from './index';
