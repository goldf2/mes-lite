'use strict';
const React = require('react');
const h = React.createElement;

/** Presentation only. The host owns login selection, sessions and authorization. */
function AuthFrame({appName, title, description, children, settingsHref='/settings', portalHref, actions=[]}) {
  return h('main', {className:'oak-auth-screen'},
    h('header', {className:'oak-auth-topbar'},
      h('span', {className:'oak-auth-topbar-name'}, appName),
      h('nav', {'aria-label':'应用导航'},
        portalHref && h('a', {href:portalHref}, '应用导航'),
        h('a', {href:settingsHref}, '系统设置'))),
    h('div', {className:'oak-auth-center'},
      h('section', {className:'oak-auth-surface', 'aria-labelledby':'oak-auth-title'},
        h('header', {className:'oak-auth-heading'},
          h('p', {className:'oak-auth-app-name'}, appName),
          h('h1', {id:'oak-auth-title'}, title),
          description && h('p', {className:'oak-auth-description'}, description)),
        h('div', {className:'oak-auth-body'}, children),
        actions.length > 0 && h('nav', {className:'oak-auth-actions', 'aria-label':'登录与设置操作'},
          ...actions.map(action => h('a', {key:action.href, href:action.href, className:action.primary?'oak-auth-primary':'oak-auth-secondary'}, action.label))))));
}
module.exports = {AuthFrame};
