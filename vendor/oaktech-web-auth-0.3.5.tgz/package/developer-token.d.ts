import type {AuthDatabase} from './index';
export interface DeveloperTokenConfig {appId:string;deploymentId:string;enabled:boolean;token:string;issuer:string;subject:'developer-token-root'}
export interface DeveloperPrincipal {authSource:'developer_token';issuer:string;subject:'developer-token-root';name:'Developer Token';superAdmin:true;authenticatedAt:number;generation:string}
export interface DeveloperRuntime {
 readonly config:DeveloperTokenConfig;readonly generation:string;
 assertActive():void;authenticate(token:unknown,peer?:string,now?:number):DeveloperPrincipal;
 bindSession(tokenHash:string,hostUserId:string,principal:DeveloperPrincipal,now?:number):void;
 session(tokenHash:string,hostUserId?:string,now?:number):(DeveloperPrincipal&{hostUserId:string})|null;
}
export function developerTokenConfigFromEnv(appId:string,deploymentId:string,env?:Record<string,string|undefined>):DeveloperTokenConfig;
export function activateDeveloperToken(db:AuthDatabase,config:DeveloperTokenConfig,now?:number):{changed:boolean;generation:string;enabled:boolean};
export function attachDeveloperToken(db:AuthDatabase,config:DeveloperTokenConfig):DeveloperRuntime;
export function invalidateDeveloperGeneration(db:AuthDatabase,config:DeveloperTokenConfig,now?:number):{generation:string};
