# @oaktech/web-auth 0.3.0

## 0.3.5 MES runtime compatibility

Supported runtimes are Node.js >=20.19 and React >=18. The complete package uses Node 20 server primitives and React createElement/useState/useEffect, without Node 22-only or React 19-only APIs. The public `casdoor-oidc` server subpath and `auth-frame` presentation subpath are validated in a separately packed consumer under Node 20.19.4 and React 18.3.1. Existing authentication, storage, protocol and UI algorithms are unchanged.

Hosts keep their own session adapter and business permissions. A Node 20 host must provide a compatible database adapter if it opts into the SQL core; `node:sqlite` is a host/test driver option, not a required package import. MES consumes only the supported public subpaths and maps verified identity to its own Prisma-backed sessions. This release alone does not switch any deployed application's login mode or identity ownership.

Server-side authentication core and reusable deployment-authentication modules for WEB-AUTH-001 2.0.0 and CT-ADMIN-001 3.2.0. Version 0.3.0 keeps the proven CloudBridge Casdoor configuration contract and upgrades the login/admin model to `APP_LOGIN_MODE=token|casdoor` (optional builtin) plus a single deployment-side `APP_ADMIN_TOKEN`.

The package deliberately does not own business Casbin models, product/subscription rules, tenant/workspace mappings, or host business sessions. Each application provides its persistent database, configuration-encryption key, host session mapping, business authorization and UI placement. Other applications consume an immutable `npm pack` archive with lockfile integrity; this is not a public npm package.

## Host responsibilities

The host owns HTTP origin/CSRF checks, request size limits, existing session tokens, external OIDC verification, business users, roles, workspace membership and business data. `attach()` never activates configuration. A deployment/startup initializer must call `activate()` before serving requests. Every protected session must check its native session AND the generation binding. An application must never infer business permissions from the package's configuration-manager flag.

`basic` validates runtime credentials. `builtin` uses explicit, deployment-created accounts and scrypt password hashes (N=32768,r=8,p=3). No public self-registration or automatic first-user administrator. `casdoor` binds the host's verified OIDC flow to configuration generation. Credentials, hashes and runtime config objects are server-only; the UI subpath does not import the core.

State tables use the `oak_auth_` namespace. The same SQL adapter supports better-sqlite3 and node:sqlite. Existing host tables are not redefined. Native sessions are retained by the host but unbound sessions cannot pass an opted-in standard mode. Activation, credential reset and disablement invalidate bindings. Going A→B→A creates a new generation; old sessions do not resurrect.

Account management functions are server primitives, not public endpoints: a host must call `requireManager`, independently validate the native user, use CSRF protection and pass a live `authorize` callback to asynchronous mutations. Deployment CLI use is explicitly trusted; credentials are supplied on stdin and must never be logged. Do not use HTTP input as an administrator flag.

## Package and testing

Source tests: `web/tests/standard-auth-core.test.ts`. Run under the host's locked Node/dependencies. Create an immutable archive with `npm pack --ignore-scripts`; consumers pin the archive integrity. Check both host drivers and real routes before delivery. UI exports have a separate client entrypoint and React is a peer dependency.

## Implemented public template and remaining scope

Version 0.3.0 implements the reusable authentication/configuration template validated by enterprise-map and logistics-profit: token/casdoor login selection, optional builtin compatibility, encrypted and revisioned Casdoor drafts, controlled discovery/JWKS/token/userinfo networking, connection checks, real test-login proof, activation with auth-generation invalidation, verified-email super-admin policy, and a permanent `APP_ADMIN_TOKEN` that supports both direct `admin_token_root` sessions and Casdoor-session Admin Elevation.

`developer-token` and `APP_AUTH_MODE` modules remain only for migration compatibility. New host integrations must use `login-mode` and `admin-token`.

The package intentionally does **not** own central membership/workspace CRUD, Casbin business models, commerce entitlement orchestration, tenant data migration, multi-replica coordination, or each application's business authorization. Those remain host/platform responsibilities and require separate deployment validation. Passing package tests does not by itself mean a production deployment has switched authentication mode.

Password-storage reference: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html

## Current-browser Casdoor logout (0.3.1)

Import `logoutCasdoorBrowser` from `@oaktech/web-auth/browser-logout`. Its only arguments are a server-selected HTTPS issuer origin and an optional fixture fetcher. The host first revokes its current Session/Elevation and pending or in-flight login challenges, clears its auth Cookies, and reaches a controlled logout page. Token-only logout never invokes this helper.

The browser performs credentialed GET `/api/get-account` and must observe an actual account (`status=ok`, nonempty `data.owner` and `data.name`). It then POSTs `/api/logout` and GETs `/api/get-account` until the explicit English `Please login first` result, with at most two POST attempts and 10 seconds per request. `data2` is ignored; the helper never navigates, reads Client Secrets, or returns account data. Failures always throw `PROVIDER_LOGOUT_UNCONFIRMED`; the host keeps local revocation and offers retry/manual IdP inspection. An anonymous preflight, unavailable CORS or blocked third-party Cookie is unconfirmed, even when logout POST would return `ok`. Hosts must validate browser Cookie behavior for their adopted site before claiming real unified logout; synthetic fixtures or no-Cookie HTTP do not prove top-level SSO ended.

Host completion must consume only a short-lived one-use logout ticket, without clearing a newer login from another tab. This package does not implement all-device logout, cross-application backchannel revocation, or automatic reauthentication. For asynchronous configuration test-login, pass `assertContext` to `completeCasdoorTestLogin` to recheck the current host session before any proof is recorded after provider I/O.

## 统一登录展示 v0.3.3

`AuthFrame`（`@oaktech/web-auth/auth-frame`）与 `@oaktech/web-auth/auth-frame.css` 为唯一登录、失败、退出、等待授权及设置页面壳。宿主传入应用名称、状态标题、文案、现有表单/退出控件与链接；壳不选择模式，不创建会话，不判断业务权限。所有状态保留公开系统设置导航，应用导航由宿主的 `portalHref` 指定。正常 Casdoor 直接起跳由宿主服务端继续执行。

`AdminTokenForm` 新增 `embedded`、`tokenLabel`、`placeholder` 纯展示参数；嵌入壳时不重复卡片和标题。普通 Token 表单使用“访问密钥”与“登录”，设置中超管使用“管理员 Token”与“以超级管理员登录”。用户页面不展示环境变量名或内部角色标识。验证、限流、提交格式、会话与撤销原语保持原实现。

Python/非 React 应用采用同一固定版本的 CSS 与 `main/header/center/surface/heading/body/actions` 结构，在 vendor manifest 登记来源版本、提交和完整性；后端认证继续用自己的已验证 adapter，不复制 Node 算法。业务页面的布局与数据权限不因此改变。

0.3.2 为内部候选；最终 0.3.3 补旧账号表单空标题不渲染，让既有 basic/builtin 模式可嵌入同一页面壳，不重复空 h1。

## 0.3.4 展示嵌入兼容

`AccountSettings`、`CasdoorConfigPanel` 可传 `embedded`，在宿主已有 `ApplicationFrame` 的 main 内使用 section/h2；默认 main/h1 保持兼容。仅改变语义标签，不改变表单、请求、认证和配置逻辑。
