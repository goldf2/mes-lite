'use strict';
const {randomBytes,createCipheriv,createDecipheriv,createHash}=require('node:crypto');
const {AuthError}=require('./mode.cjs');
const {loginModeFromEnv}=require('./login-mode.cjs');
const FIELDS=['issuer','clientId','application','organization','discoveryUrl','scopes'];
const PROOF_TTL=10*60_000;
function opaque(){return randomBytes(24).toString('base64url');}
function tx(db,fn){db.exec('BEGIN IMMEDIATE');try{const v=fn();db.exec('COMMIT');return v;}catch(e){db.exec('ROLLBACK');throw e;}}
function validateOrigin(raw){
 let u;try{u=new URL(raw);}catch{throw new AuthError('APP_ORIGIN_INVALID',503);}
 if(u.username||u.password||u.search||u.hash||u.pathname!=='/'||!(u.protocol==='https:'||(u.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(u.hostname))))throw new AuthError('APP_ORIGIN_INVALID',503);
 return u.origin;
}
function validateIssuer(raw){
 let u;try{u=new URL(raw);}catch{throw new AuthError('CASDOOR_ISSUER_INVALID');}
 if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||!u.hostname)throw new AuthError('CASDOOR_ISSUER_INVALID');
 return String(raw).trim();
}
function text(value,max=256){
 if(value===undefined||value===null)return '';if(typeof value!=='string'||value.length>max||[...value].some(c=>c.charCodeAt(0)<32||c.charCodeAt(0)===127))throw new AuthError('CASDOOR_CONFIG_INVALID');return value.trim();
}
function scopes(value){
 const list=Array.isArray(value)?value:typeof value==='string'?value.split(/\s+/):['openid','profile','email'],out=[...new Set(list.map(x=>String(x).trim()).filter(Boolean))];
 if(!out.includes('openid')||out.length>20||out.some(x=>x.length>80||!/^[A-Za-z0-9._:-]+$/.test(x)))throw new AuthError('CASDOOR_SCOPES_INVALID');return out.join(' ');
}
function validateFields(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw new AuthError('CASDOOR_CONFIG_INVALID');
 const issuer=validateIssuer(input.issuer),clientId=text(input.clientId,512);if(!clientId)throw new AuthError('CASDOOR_CLIENT_ID_INVALID');
 const discoveryUrl=text(input.discoveryUrl,2048);if(discoveryUrl){let d;try{d=new URL(discoveryUrl);}catch{throw new AuthError('CASDOOR_DISCOVERY_INVALID');}if(d.protocol!=='https:'||d.username||d.password||d.hash||d.origin!==new URL(issuer).origin)throw new AuthError('CASDOOR_DISCOVERY_INVALID');}
 return {issuer,clientId,application:text(input.application),organization:text(input.organization),discoveryUrl,scopes:scopes(input.scopes)};
}
function environmentConfig(env){
 const raw={issuer:env.CASDOOR_ISSUER||'',clientId:env.CASDOOR_CLIENT_ID||'',clientSecret:env.CASDOOR_CLIENT_SECRET||'',application:env.CASDOOR_APPLICATION||'',organization:env.CASDOOR_ORGANIZATION||'',discoveryUrl:env.CASDOOR_DISCOVERY_URL||'',scopes:env.CASDOOR_SCOPES||'openid profile email'};
 if(![raw.issuer,raw.clientId,raw.clientSecret,raw.application,raw.organization,raw.discoveryUrl].some(Boolean))return null;
 const fields=validateFields(raw);if(typeof raw.clientSecret!=='string'||!raw.clientSecret||Buffer.byteLength(raw.clientSecret,'utf8')>4096)throw new AuthError('CASDOOR_CONFIGURATION_REQUIRED',503);
 return {...fields,clientSecret:raw.clientSecret};
}
function parseKey(raw){
 if(typeof raw!=='string'||!raw)throw new AuthError('CONFIG_ENCRYPTION_KEY_REQUIRED',503);
 let key;if(/^[a-f0-9]{64}$/i.test(raw))key=Buffer.from(raw,'hex');else{try{key=Buffer.from(raw,'base64url')}catch{}}
 if(!key||key.length!==32)throw new AuthError('CONFIG_ENCRYPTION_KEY_INVALID',503);return key;
}
function createAesGcmCodec(rawKey){
 const key=parseKey(rawKey),keyId=createHash('sha256').update(key).digest('hex').slice(0,16);
 return {
  keyId,
  encrypt(value,aad){const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv);cipher.setAAD(Buffer.from(aad));const body=Buffer.concat([cipher.update(String(value),'utf8'),cipher.final()]);return JSON.stringify({v:1,iv:iv.toString('base64url'),tag:cipher.getAuthTag().toString('base64url'),body:body.toString('base64url')});},
  decrypt(value,aad){try{const data=JSON.parse(value);if(data.v!==1)throw new Error();const decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(data.iv,'base64url'));decipher.setAAD(Buffer.from(aad));decipher.setAuthTag(Buffer.from(data.tag,'base64url'));return Buffer.concat([decipher.update(Buffer.from(data.body,'base64url')),decipher.final()]).toString('utf8');}catch{throw new AuthError('CASDOOR_CONFIG_DECRYPT_FAILED',503);}}
 };
}
function install(db){
 db.exec(`
  CREATE TABLE IF NOT EXISTS oak_casdoor_config_meta(
   id INTEGER PRIMARY KEY CHECK(id=1),deployment_id TEXT NOT NULL,source TEXT NOT NULL CHECK(source IN('none','database')),
   draft_revision TEXT,active_revision TEXT,auth_generation INTEGER NOT NULL DEFAULT 0,runtime_mode TEXT);
  CREATE TABLE IF NOT EXISTS oak_casdoor_config_revisions(
   revision TEXT PRIMARY KEY,kind TEXT NOT NULL CHECK(kind IN('draft','active')),encrypted_config TEXT NOT NULL,key_id TEXT NOT NULL,created_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS oak_casdoor_config_results(
   revision TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN('check','test')),context_id TEXT NOT NULL,generation INTEGER NOT NULL,
   success INTEGER NOT NULL,code TEXT NOT NULL,recorded_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,
   PRIMARY KEY(revision,kind,context_id));
  CREATE TABLE IF NOT EXISTS oak_casdoor_test_states(
   ticket_hash TEXT PRIMARY KEY,context_id TEXT NOT NULL,revision TEXT NOT NULL,generation INTEGER NOT NULL,
   verifier TEXT NOT NULL,state TEXT NOT NULL,nonce TEXT NOT NULL,expires_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS oak_casdoor_config_audit(
   id INTEGER PRIMARY KEY,at INTEGER NOT NULL,action TEXT NOT NULL,actor TEXT NOT NULL,revision TEXT,result TEXT NOT NULL,fields TEXT NOT NULL);
 `);
}
function createCasdoorConfigStore(db,options={}){
 const appId=options.appId;if(typeof appId!=='string'||!/^[a-z][a-z0-9-]{2,79}$/.test(appId))throw new AuthError('APP_ID_INVALID',503);
 const origin=validateOrigin(options.origin),callbackPath=typeof options.callbackPath==='string'&&/^\/[A-Za-z0-9_./-]{1,200}$/.test(options.callbackPath)?options.callbackPath:null;
 if(!callbackPath)throw new AuthError('CASDOOR_CALLBACK_INVALID',503);
 const callbackUrl=origin+callbackPath,env=options.env||process.env,codec=options.codec||null;
 install(db);let meta=db.prepare('SELECT * FROM oak_casdoor_config_meta WHERE id=1').get();
 if(!meta){db.prepare("INSERT INTO oak_casdoor_config_meta(id,deployment_id,source) VALUES(1,?,'none')").run(opaque());meta=db.prepare('SELECT * FROM oak_casdoor_config_meta WHERE id=1').get();}
 const deploymentId=meta.deployment_id;
 function audit(action,actor,revision,result='ok',fields=[],at=Date.now()){db.prepare('INSERT INTO oak_casdoor_config_audit(at,action,actor,revision,result,fields) VALUES(?,?,?,?,?,?)').run(at,action,String(actor||'configuration-admin').slice(0,128),typeof revision==='string'?revision:null,result,JSON.stringify([...new Set(fields)].filter(x=>[...FIELDS,'clientSecret'].includes(x)).sort()));}
 function currentMeta(){const row=db.prepare('SELECT * FROM oak_casdoor_config_meta WHERE id=1').get();if(!row||!['none','database'].includes(row.source))throw new AuthError('CASDOOR_CONFIG_CORRUPT',503);return row;}
 function envConfig(){return environmentConfig(env);}
 function state(){const row=currentMeta();let source=row.source;if(source!=='database')source=envConfig()?'environment':'none';return {deploymentId,source,draftRevision:row.draft_revision,activeRevision:source==='database'?row.active_revision:source==='environment'?'environment':null,authGeneration:row.auth_generation,runtimeMode:row.runtime_mode};}
 function aad(revision){return `oaktech-casdoor-v1:${appId}:${deploymentId}:${revision}`;}
 function readRevision(revision){
  const row=db.prepare('SELECT * FROM oak_casdoor_config_revisions WHERE revision=?').get(revision);if(!row)throw new AuthError('CASDOOR_CONFIG_CORRUPT',503);
  if(!codec||row.key_id!==codec.keyId)throw new AuthError('CASDOOR_CONFIG_KEY_MISMATCH',503);
  try{const value=JSON.parse(codec.decrypt(row.encrypted_config,aad(revision)));const fields=validateFields(value);if(typeof value.clientSecret!=='string'||!value.clientSecret||Buffer.byteLength(value.clientSecret,'utf8')>4096)throw new Error();return {...fields,clientSecret:value.clientSecret};}
  catch(e){if(e instanceof AuthError)throw e;throw new AuthError('CASDOOR_CONFIG_CORRUPT',503);}
 }
 function active(){
  const s=state();if(s.source==='database'){if(!s.activeRevision)throw new AuthError('CASDOOR_CONFIG_CORRUPT',503);return readRevision(s.activeRevision);}
  if(s.source==='environment')return envConfig();return null;
 }
 function publicConfig(config){return config?{...Object.fromEntries(FIELDS.map(k=>[k,config[k]||''])),secretConfigured:Boolean(config.clientSecret)}:null;}
 function result(revision,generation,kind){
  if(!revision)return {status:'unverified',code:'',expiresAt:null};
  const row=db.prepare('SELECT * FROM oak_casdoor_config_results WHERE revision=? AND kind=? ORDER BY recorded_at DESC LIMIT 1').get(revision,kind);
  if(!row)return {status:'unverified',code:'',expiresAt:null};
  const expired=row.generation!==generation||row.expires_at<=Date.now();return {status:expired?'expired':row.success?'passed':'failed',code:row.code,expiresAt:row.expires_at};
 }
 function redacted(mode){
  const s=state(),draft=s.draftRevision?readRevision(s.draftRevision):null;return {...s,mode,callbackUrl,keyId:codec?.keyId||null,encryptionReady:Boolean(codec),active:publicConfig(active()),draft:publicConfig(draft),check:result(s.draftRevision,s.authGeneration,'check'),test:result(s.draftRevision,s.authGeneration,'test')};
 }
 function expect(expected,generation){
  const s=state();if(expected!==s.draftRevision||(generation!==undefined&&generation!==s.authGeneration))throw new AuthError('CASDOOR_CONFIG_CONFLICT',409);return s;
 }
 function insertRevision(config,kind,now=Date.now()){
  if(!codec)throw new AuthError('CONFIG_ENCRYPTION_KEY_REQUIRED',503);const revision=opaque(),payload=codec.encrypt(JSON.stringify(config),aad(revision));
  db.prepare('INSERT INTO oak_casdoor_config_revisions VALUES(?,?,?,?,?)').run(revision,kind,payload,codec.keyId,now);return revision;
 }
 function clearProofs(){db.prepare('DELETE FROM oak_casdoor_config_results').run();db.prepare('DELETE FROM oak_casdoor_test_states').run();}
 function beginRuntime(mode){
  if(!['token','basic','builtin','casdoor'].includes(mode))throw new AuthError('LOGIN_MODE_INVALID',503);return tx(db,()=>{db.prepare('UPDATE oak_casdoor_config_meta SET auth_generation=auth_generation+1,runtime_mode=? WHERE id=1').run(mode);clearProofs();return state();});
 }
 function saveDraft(expectedRevision,fields,secretAction='keep',secretValue='',actor='configuration-admin',expectedGeneration){
  const touched=Object.keys(fields||{});if(secretAction!=='keep')touched.push('clientSecret');
  try{return tx(db,()=>{const s=expect(expectedRevision,expectedGeneration),validated=validateFields(fields||{});let base=expectedRevision?readRevision(expectedRevision):s.source==='database'?active():{issuer:'',clientId:'',application:'',organization:'',discoveryUrl:'',scopes:'openid profile email',clientSecret:''};
   base={...base,...validated};if(!['keep','replace','clear'].includes(secretAction)||typeof secretValue!=='string')throw new AuthError('CASDOOR_SECRET_ACTION_INVALID');
   if(secretAction==='replace'){if(!secretValue.trim()||Buffer.byteLength(secretValue,'utf8')>4096||/^\*+$/.test(secretValue.trim()))throw new AuthError('CASDOOR_CLIENT_SECRET_INVALID');base.clientSecret=secretValue;}
   else if(secretAction==='clear'){if(secretValue)throw new AuthError('CASDOOR_SECRET_ACTION_INVALID');base.clientSecret='';}
   else if(secretValue)throw new AuthError('CASDOOR_SECRET_ACTION_INVALID');
   const revision=insertRevision(base,'draft');db.prepare('UPDATE oak_casdoor_config_meta SET draft_revision=? WHERE id=1').run(revision);clearProofs();audit('save-draft',actor,revision,'ok',touched);return redacted(s.runtimeMode);
  });}catch(e){audit('save-draft',actor,expectedRevision,e instanceof AuthError?e.code:'failed',touched);throw e;}
 }
 function importEnvironment(expectedRevision,actor='configuration-admin',expectedGeneration){
  const config=envConfig();if(!config)throw new AuthError('CASDOOR_ENVIRONMENT_CONFIG_REQUIRED',409);
  return tx(db,()=>{const s=expect(expectedRevision,expectedGeneration),revision=insertRevision(config,'draft');db.prepare('UPDATE oak_casdoor_config_meta SET draft_revision=? WHERE id=1').run(revision);clearProofs();audit('import-environment',actor,revision,'ok',[...FIELDS,'clientSecret']);return redacted(s.runtimeMode);});
 }
 function readDraft(expectedRevision){expect(expectedRevision);if(!expectedRevision)throw new AuthError('CASDOOR_CONFIG_DRAFT_REQUIRED',409);return readRevision(expectedRevision);}
 function record(kind,revision,generation,contextId,success,code='',actor='configuration-admin'){
  if(!['check','test'].includes(kind)||typeof success!=='boolean'||typeof contextId!=='string'||contextId.length<8||contextId.length>256)throw new AuthError('CASDOOR_PROOF_INVALID');
  return tx(db,()=>{expect(revision,generation);readRevision(revision);if(kind==='test'&&result(revision,generation,'check').status!=='passed')throw new AuthError('CASDOOR_CHECK_REQUIRED',409);
   const now=Date.now();db.prepare(`INSERT INTO oak_casdoor_config_results VALUES(?,?,?,?,?,?,?,?)
    ON CONFLICT(revision,kind,context_id) DO UPDATE SET generation=excluded.generation,success=excluded.success,code=excluded.code,recorded_at=excluded.recorded_at,expires_at=excluded.expires_at`)
    .run(revision,kind,contextId,generation,success?1:0,String(code||'').slice(0,80),now,now+PROOF_TTL);audit(kind==='check'?'check':'test-login',actor,revision,success?'passed':'failed');return redacted(state().runtimeMode);
  });
 }
 function recordCheck(revision,generation,success,code='',actor='configuration-admin'){return record('check',revision,generation,'connection',success,code,actor);}
 function recordTest(revision,generation,contextId,success=true,code='',actor='configuration-admin'){return record('test',revision,generation,contextId,success,code,actor);}
 function createTestState(revision,generation,contextId,data,now=Date.now()){
  expect(revision,generation);if(result(revision,generation,'check').status!=='passed')throw new AuthError('CASDOOR_CHECK_REQUIRED',409);
  const ticket=opaque();db.prepare('DELETE FROM oak_casdoor_test_states WHERE expires_at<=?').run(now);
  db.prepare('INSERT INTO oak_casdoor_test_states VALUES(?,?,?,?,?,?,?,?)').run(createHash('sha256').update(ticket).digest('hex'),contextId,revision,generation,data.verifier,data.state,data.nonce,now+5*60_000);
  return {ticket,revision,generation,contextId,expiresAt:now+5*60_000};
 }
 function consumeTestState(ticket,contextId,now=Date.now()){
  return tx(db,()=>{const hash=createHash('sha256').update(String(ticket)).digest('hex'),row=db.prepare('SELECT * FROM oak_casdoor_test_states WHERE ticket_hash=? AND context_id=? AND expires_at>?').get(hash,contextId,now);db.prepare('DELETE FROM oak_casdoor_test_states WHERE ticket_hash=?').run(hash);
   if(!row)throw new AuthError('CASDOOR_TEST_EXPIRED',401);expect(row.revision,row.generation);return row;
  });
 }
 function activate(expectedRevision,actor,contextId){
  return tx(db,()=>{const s=expect(expectedRevision),check=result(expectedRevision,s.authGeneration,'check'),test=result(expectedRevision,s.authGeneration,'test');
   if(check.status!=='passed'||test.status!=='passed')throw new AuthError('CASDOOR_CONFIG_NOT_VERIFIED',409);
   const proof=db.prepare("SELECT 1 FROM oak_casdoor_config_results WHERE revision=? AND kind='test' AND context_id=? AND generation=? AND success=1 AND expires_at>?").get(expectedRevision,contextId,s.authGeneration,Date.now());
   if(!proof)throw new AuthError('CASDOOR_TEST_CONTEXT_REQUIRED',409);
   const config=readRevision(expectedRevision),activeRevision=insertRevision(config,'active');db.prepare("UPDATE oak_casdoor_config_meta SET source='database',active_revision=?,auth_generation=auth_generation+1 WHERE id=1").run(activeRevision);clearProofs();audit('activate',actor,activeRevision,'ok');return {activeRevision,state:state(),config};
  });
 }
 return {appId,deploymentId,origin,callbackUrl,state,redacted,active,readDraft,saveDraft,importEnvironment,recordCheck,recordTest,createTestState,consumeTestState,activate,beginRuntime};
}
function effectiveAuthConfig(db,options,env=process.env){
 const mode=loginModeFromEnv(env,options.legacyDefault||'casdoor');
 if(mode==='token')throw new AuthError('TOKEN_MODE_USES_ADMIN_TOKEN',503);
 if(mode!=='casdoor'){
  const {configFromEnv}=require('./index.cjs');
  if(env.APP_LOGIN_MODE==='builtin'){
   const compat={...env,APP_AUTH_MODE:'builtin'};delete compat.APP_LOGIN_MODE;delete compat.AUTH_MODE;return configFromEnv(options.appId,compat);
  }
  return configFromEnv(options.appId,env);
 }
 const store=createCasdoorConfigStore(db,{...options,env}),config=store.active();if(!config)throw new AuthError('CASDOOR_CONFIGURATION_REQUIRED',503);
 return Object.freeze({appId:options.appId,mode:'casdoor',origin:store.origin,issuer:config.issuer,clientId:config.clientId,clientSecret:config.clientSecret,application:config.application,organization:config.organization,discoveryUrl:config.discoveryUrl,scopes:config.scopes});
}
module.exports={createAesGcmCodec,createCasdoorConfigStore,effectiveAuthConfig,environmentConfig,validateFields};
