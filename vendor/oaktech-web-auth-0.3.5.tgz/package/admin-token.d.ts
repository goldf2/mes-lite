export interface AdminTokenConfig {appId:string;deploymentId:string;token:string;issuer:string;subject:'admin_token_root'}
export interface AdminPrincipal {authSource:'admin_token';issuer:string;subject:'admin_token_root';name:'Admin Token';superAdmin:true;authenticatedAt:number;generation:string}
export interface AdminDirectSession extends AdminPrincipal {hostUserId:string}
export interface AdminElevation {authSource:'admin_token_elevation';issuer:string;subject:string;superAdmin:true;hostUserId:string;authenticatedAt:number;generation:string}
export interface AdminTokenRuntime {
 readonly config:AdminTokenConfig;readonly generation:string;assertActive():void;
 authenticate(token:unknown,peer?:string,now?:number):AdminPrincipal;
 bindDirectSession(tokenHash:string,hostUserId:string,principal:AdminPrincipal,now?:number):void;
 directSession(tokenHash:string,hostUserId?:string,now?:number):AdminDirectSession|null;
 bindElevation(tokenHash:string,hostUserId:string,issuer:string,subject:string,principal:AdminPrincipal,now?:number):void;
 elevation(tokenHash:string,hostUserId:string,issuer:string,subject:string,now?:number):AdminElevation|null;
 revokeElevation(tokenHash:string,hostUserId:string):void;
}
export function adminTokenConfigFromEnv(appId:string,deploymentId:string,env?:Record<string,string|undefined>):AdminTokenConfig;
export function activateAdminToken(db:any,config:AdminTokenConfig,now?:number):{changed:boolean;generation:string};
export function attachAdminToken(db:any,config:AdminTokenConfig):AdminTokenRuntime;
export function invalidateAdminGeneration(db:any,config:AdminTokenConfig,now?:number):{generation:string};
