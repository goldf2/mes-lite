/** Current-browser Casdoor logout. The host must revoke its local session first. */
export async function logoutCasdoorBrowser(issuerOrigin, fetcher = globalThis.fetch) {
  const failure = () => Object.assign(new Error('PROVIDER_LOGOUT_UNCONFIRMED'), {code: 'PROVIDER_LOGOUT_UNCONFIRMED'});
  let origin;
  try {
    const issuer = new URL(issuerOrigin);
    if (issuer.protocol !== 'https:' || issuer.username || issuer.password || issuer.search || issuer.hash || issuer.pathname !== '/') throw failure();
    origin = issuer.origin;
  } catch { throw failure(); }
  const call = async (path, method) => {
    try {
      const response = await fetcher(origin + path, {
        method, credentials: 'include', redirect: 'error', cache: 'no-store',
        headers: {'Accept-Language': 'en'}, signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw failure();
      return await response.json();
    } catch { throw failure(); }
  };
  // A blocked third-party Cookie can look anonymous even while top-level SSO survives.
  // Require an observable browser account before attempting/confirming its logout.
  const before = await call('/api/get-account', 'GET');
  if (before?.status !== 'ok' || !before.data || typeof before.data !== 'object' ||
      typeof before.data.owner !== 'string' || !before.data.owner ||
      typeof before.data.name !== 'string' || !before.data.name) throw failure();
  for (let attempt = 0; attempt < 2; attempt++) {
    const result = await call('/api/logout', 'POST');
    if (result?.status !== 'ok') throw failure();
    // Casdoor data2 can be a different application's homepage: never follow it.
    const account = await call('/api/get-account', 'GET');
    if (account?.status === 'error' && account.msg === 'Please login first') return {confirmed: true};
    if (account?.status !== 'ok') throw failure();
  }
  throw failure();
}
