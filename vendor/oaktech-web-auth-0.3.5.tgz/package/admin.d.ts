import type {AuthDatabase} from './index';
export interface TrustedIdentity {issuer:string;subject:string;email?:unknown;emailVerified?:unknown}
export interface SuperAdminPolicy {
 reload(value:string|undefined):void;
 remember(identity:TrustedIdentity,now?:number):void;
 canManage(issuer:string,subject:string):boolean;
 snapshot(issuer:string,subject:string):{email:string;emailVerified:boolean;lastSeen:number;superAdmin:boolean;configurationError:string}|null;
 status():{configurationError:string;configuredCount:number};
}
export function normalizeEmail(value:unknown):string|null;
export function parseSuperAdminEmails(value:string|undefined):Set<string>;
export function createSuperAdminPolicy(db:AuthDatabase,configured:string|undefined):SuperAdminPolicy;
