'use client';
'use strict';
const React = require('react');
const { useState, useEffect } = React;
const h = React.createElement;
const errors = {
  INVALID_CREDENTIALS:'账号或密码不正确。', LOGIN_RATE_LIMITED:'尝试次数过多，请稍后重试。', AUTH_BUSY:'登录服务繁忙，请稍后重试。',
  PASSWORD_LENGTH:'密码至少需要 15 个字符，且不能超过 1024 字节。', INVALID_USERNAME:'账号需为 3—80 位字母、数字及 . _ @ + -。', INVALID_NAME:'请填写有效的名称。',
  USERNAME_EXISTS:'该账号已存在。', USER_CHANGED:'账号已被修改，请刷新后重试。', RECENT_LOGIN_REQUIRED:'此操作需要近期登录，请退出后重新登录。',
  LOGIN_REQUIRED:'登录已失效，请重新登录。', AUTH_CONFIGURATION_CHANGED:'认证配置已更新，请重新登录。', AUTH_MANAGER_REQUIRED:'当前账号没有管理登录账号的权限。',
  AUTH_CONFIGURATION_NOT_ACTIVE:'认证配置尚未生效，请联系部署负责人。', AUTH_INITIALIZATION_REQUIRED:'认证尚未初始化，请联系部署负责人。',
  SELF_DISABLE_REFUSED:'请由另一位管理者执行停用，或使用部署侧管理命令。'
};
function message(code) { return errors[code] || '操作未完成，请检查输入或联系管理员。'; }
async function request(endpoint, data) {
  const response = await fetch(endpoint, {method:data === undefined?'GET':'POST',credentials:'same-origin',cache:'no-store',headers:data===undefined?{}:{'Content-Type':'application/json'},body:data===undefined?undefined:JSON.stringify(data)});
  const result = await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(message(result.error));
  return result;
}
function field(label,name,type='text',extra={}) {
  return h('label',{className:'oak-auth-label',key:name},label,h('input',{className:'oak-auth-input',name,type,required:true,...extra}));
}
function submit(text,busy) {return h('button',{type:'submit',className:'oak-auth-button',disabled:busy},busy?'正在处理…':text);}
function CredentialForm({endpoint,title='登录',description='',next='/'}) {
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[ready,setReady]=useState(false);
  useEffect(()=>{setReady(true);},[]);
  async function login(event) {
    event.preventDefault();if(busy)return;setBusy(true);setError('');
    const form=event.currentTarget,data=new FormData(form);
    try{const result=await request(endpoint,{username:data.get('username'),password:data.get('password'),next});form.reset();window.location.assign(result.next||'/');}
    catch(e){setError(e.message);setBusy(false);}
  }
  return h('section',{className:'oak-auth-card'},title&&h('h1',null,title),description&&h('p',{className:'oak-auth-muted'},description),
    h('form',{method:'post',action:endpoint,onSubmit:login,className:'oak-auth-form'},field('账号','username','text',{autoComplete:'username',maxLength:80,autoCapitalize:'none',spellCheck:false}),
      field('密码','password','password',{autoComplete:'current-password',maxLength:1024}),error&&h('p',{role:'alert',className:'oak-auth-error'},error),submit('登录',busy||!ready)));
}
function AccountSettings({mode,manager,accountEndpoint,passwordEndpoint,home='/',title='账号与登录',embedded=false}) {
  const [users,setUsers]=useState([]),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState(''),[ready,setReady]=useState(false);
  useEffect(()=>{setReady(true);},[]);
  const load=async()=>{if(manager){const data=await request(accountEndpoint);setUsers(data.users||[]);}};
  useEffect(()=>{let live=true;if(manager)request(accountEndpoint).then(d=>{if(live)setUsers(d.users||[]);}).catch(e=>{if(live)setError(e.message);});return()=>{live=false;};},[manager,accountEndpoint]);
  async function perform(operation) {if(busy)return;setBusy(true);setError('');setNotice('');try{await operation();}catch(e){setError(e.message);}finally{setBusy(false);}}
  function create(event){event.preventDefault();const form=event.currentTarget,data=new FormData(form);void perform(async()=>{await request(accountEndpoint,{action:'create',username:data.get('username'),name:data.get('name'),password:data.get('password')});form.reset();await load();setNotice('登录账号已创建；业务角色和工作组仍需另行授权。');});}
  function reset(event){event.preventDefault();const form=event.currentTarget,data=new FormData(form),user=users.find(u=>u.id===data.get('id'));if(!user){setError('请选择账号。');return;}void perform(async()=>{await request(accountEndpoint,{action:'reset-password',id:user.id,revision:user.revision,password:data.get('password')});form.reset();await load();setNotice('密码已重置，该账号原有会话已失效。');});}
  function change(event){event.preventDefault();const form=event.currentTarget,data=new FormData(form);void perform(async()=>{await request(passwordEndpoint,{currentPassword:data.get('currentPassword'),password:data.get('password')});form.reset();window.location.assign('/login');});}
  return h(embedded?'section':'main',{className:'oak-auth-settings'},h('a',{href:home},'← 返回应用'),h(embedded?'h2':'h1',null,title),
    h('p',{className:'oak-auth-muted'},'当前模式：'+({basic:'基础认证',builtin:'内置账号认证',casdoor:'Casdoor 认证'}[mode]||mode)+'。模式由部署环境选择。'),
    error&&h('p',{role:'alert',className:'oak-auth-error'},error),notice&&h('p',{role:'status'},notice),
    mode==='basic'&&h('p',{className:'oak-auth-muted'},'当前登录凭证由部署负责人在环境变量中维护。下方内置账号可供切换到内置认证后使用，不会自动获得原有业务数据。'),
    mode==='builtin'&&h('section',{className:'oak-auth-card'},h('h2',null,'修改我的密码'),h('form',{method:'post',action:passwordEndpoint,onSubmit:change,className:'oak-auth-form'},
      field('当前密码','currentPassword','password',{autoComplete:'current-password'}),field('新密码','password','password',{minLength:15,maxLength:1024,autoComplete:'new-password'}),submit('修改并重新登录',busy||!ready))),
    manager&&h(React.Fragment,null,
      h('section',{className:'oak-auth-card'},h('h2',null,'内置登录账号'),h('p',{className:'oak-auth-muted'},'这里只管理登录凭证；公司、工作组和业务角色仍由应用权限管理。'),
        h('div',{className:'oak-auth-user-list'},...users.map(u=>h('div',{className:'oak-auth-user',key:u.id},h('div',null,h('strong',null,u.name),h('span',null,' · '+u.username+' · '+(u.disabled?'已停用':'正常'))),
          h('button',{type:'button',className:'oak-auth-secondary',disabled:busy,onClick:()=>void perform(async()=>{await request(accountEndpoint,{action:'disable',id:u.id,revision:u.revision,disabled:!u.disabled});await load();setNotice(u.disabled?'账号已启用，需要重新登录。':'账号已停用，原会话已失效。');})},u.disabled?'启用':'停用'))))),
      h('section',{className:'oak-auth-card'},h('h2',null,'创建内置账号'),h('form',{method:'post',action:accountEndpoint,onSubmit:create,className:'oak-auth-form'},field('显示名称','name','text',{maxLength:160}),field('登录账号','username','text',{maxLength:80,autoComplete:'off',autoCapitalize:'none'}),field('初始密码','password','password',{minLength:15,maxLength:1024,autoComplete:'new-password'}),submit('创建账号',busy||!ready))),
      h('section',{className:'oak-auth-card'},h('h2',null,'重置内置账号密码'),h('form',{method:'post',action:accountEndpoint,onSubmit:reset,className:'oak-auth-form'},h('label',{className:'oak-auth-label'},'账号',h('select',{name:'id',className:'oak-auth-input',required:true,defaultValue:''},h('option',{value:'',disabled:true},'请选择账号'),...users.map(u=>h('option',{key:u.id,value:u.id},u.name+' · '+u.username)))),field('新密码','password','password',{minLength:15,maxLength:1024,autoComplete:'new-password'}),submit('重置密码',busy||!ready)))));
}
module.exports = { CredentialForm, AccountSettings };
