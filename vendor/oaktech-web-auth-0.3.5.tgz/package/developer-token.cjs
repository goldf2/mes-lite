'use strict';
const {randomBytes,createHash,scryptSync,timingSafeEqual}=require('node:crypto');
const {AuthError}=require('./mode.cjs');
const SCRYPT={N:32768,r:8,p:3,maxmem:64*1024*1024};
const cache=new Map();
function digest(v){return createHash('sha256').update(String(v)).digest('hex');}
function equal(a,b){return timingSafeEqual(createHash('sha256').update(String(a)).digest(),createHash('sha256').update(String(b)).digest());}
function tx(db,fn){db.exec('BEGIN IMMEDIATE');try{const v=fn();db.exec('COMMIT');return v;}catch(e){db.exec('ROLLBACK');throw e;}}
function bool(value,name){
 if(value===undefined||value==='')return false;if(value==='true')return true;if(value==='false')return false;throw new AuthError(name+'_INVALID',503);
}
function developerTokenConfigFromEnv(appId,deploymentId,env=process.env){
 if(!/^[a-z][a-z0-9-]{2,79}$/.test(appId))throw new AuthError('APP_ID_INVALID',503);
 if(typeof deploymentId!=='string'||!/^[A-Za-z0-9_-]{16,128}$/.test(deploymentId))throw new AuthError('DEPLOYMENT_ID_INVALID',503);
 const enabled=bool(env.APP_DEVELOPER_TOKEN_ENABLED,'APP_DEVELOPER_TOKEN_ENABLED'),token=env.APP_DEVELOPER_ADMIN_TOKEN||'';
 if(enabled&&(typeof token!=='string'||Buffer.byteLength(token,'utf8')<32||Buffer.byteLength(token,'utf8')>4096))throw new AuthError('DEVELOPER_TOKEN_REQUIRED',503);
 return Object.freeze({appId,deploymentId,enabled,token,issuer:`urn:oaktech:${appId}:${deploymentId}`,subject:'developer-token-root'});
}
function install(db){
 db.exec(`
  CREATE TABLE IF NOT EXISTS oak_developer_state(
   id INTEGER PRIMARY KEY CHECK(id=1),schema_version INTEGER NOT NULL,app_id TEXT NOT NULL,deployment_id TEXT NOT NULL,
   enabled INTEGER NOT NULL,generation TEXT NOT NULL,salt TEXT NOT NULL,fingerprint TEXT NOT NULL,activated_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS oak_developer_sessions(
   token_hash TEXT PRIMARY KEY,host_user_id TEXT NOT NULL,generation TEXT NOT NULL,authenticated_at INTEGER NOT NULL,expires_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS oak_developer_attempts(bucket TEXT PRIMARY KEY,attempts INTEGER NOT NULL,expires_at INTEGER NOT NULL);
 `);
}
function fingerprint(config,salt){
 const text=JSON.stringify([config.appId,config.deploymentId,config.enabled,config.token]),k=digest(salt+text);if(cache.has(k))return cache.get(k);
 const out=scryptSync(text,Buffer.from(salt,'hex'),32,SCRYPT).toString('hex');if(cache.size>8)cache.clear();cache.set(k,out);return out;
}
function activateDeveloperToken(db,config,now=Date.now()){
 install(db);return tx(db,()=>{
  const prev=db.prepare('SELECT * FROM oak_developer_state WHERE id=1').get();
  if(prev&&(prev.schema_version!==1||prev.app_id!==config.appId||prev.deployment_id!==config.deploymentId))throw new AuthError('DEVELOPER_STORE_MISMATCH',503);
  const salt=prev?.salt||randomBytes(16).toString('hex'),fp=fingerprint(config,salt);
  if(prev&&equal(prev.fingerprint,fp))return {changed:false,generation:prev.generation,enabled:Boolean(prev.enabled)};
  const generation=randomBytes(24).toString('hex');
  db.prepare(`INSERT INTO oak_developer_state VALUES(1,1,?,?,?,?,?,?,?)
   ON CONFLICT(id) DO UPDATE SET enabled=excluded.enabled,generation=excluded.generation,fingerprint=excluded.fingerprint,activated_at=excluded.activated_at`)
   .run(config.appId,config.deploymentId,config.enabled?1:0,generation,salt,fp,now);
  db.prepare('DELETE FROM oak_developer_sessions').run();db.prepare('DELETE FROM oak_developer_attempts').run();
  return {changed:true,generation,enabled:config.enabled};
 });
}
function attachDeveloperToken(db,config){
 install(db);const state=db.prepare('SELECT * FROM oak_developer_state WHERE id=1').get();
 if(!state)throw new AuthError('DEVELOPER_INITIALIZATION_REQUIRED',503);
 if(state.schema_version!==1||state.app_id!==config.appId||state.deployment_id!==config.deploymentId||!equal(state.fingerprint,fingerprint(config,state.salt)))throw new AuthError('DEVELOPER_CONFIGURATION_NOT_ACTIVE',503);
 const generation=state.generation;
 function assertActive(){const live=db.prepare('SELECT * FROM oak_developer_state WHERE id=1').get();if(!live||live.generation!==generation||!equal(live.fingerprint,fingerprint(config,live.salt)))throw new AuthError('DEVELOPER_CONFIGURATION_CHANGED',409);}
 function throttle(peer,now){
  const key=digest(typeof peer==='string'&&peer?peer:'unknown');tx(db,()=>{assertActive();db.prepare('DELETE FROM oak_developer_attempts WHERE expires_at<=?').run(now);
   for(const [bucket,max] of [['global',60],[`peer:${key}`,10]]){const row=db.prepare('SELECT attempts FROM oak_developer_attempts WHERE bucket=?').get(bucket);if(row&&row.attempts>=max)throw new AuthError('LOGIN_RATE_LIMITED',429);}
   db.prepare("INSERT INTO oak_developer_attempts VALUES('global',1,?) ON CONFLICT(bucket) DO UPDATE SET attempts=attempts+1").run(now+60000);
   db.prepare('INSERT INTO oak_developer_attempts VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET attempts=attempts+1').run(`peer:${key}`,now+300000);
  });
 }
 function authenticate(value,peer='unknown',now=Date.now()){
  assertActive();throttle(peer,now);if(!config.enabled)throw new AuthError('LOGIN_METHOD_DISABLED',404);
  const valid=typeof value==='string'&&Buffer.byteLength(value,'utf8')<=4096&&equal(value,config.token);
  if(!valid)throw new AuthError('INVALID_CREDENTIALS',401);
  db.prepare('DELETE FROM oak_developer_attempts WHERE bucket=?').run(`peer:${digest(peer||'unknown')}`);
  return {authSource:'developer_token',issuer:config.issuer,subject:config.subject,name:'Developer Token',superAdmin:true,authenticatedAt:now,generation};
 }
 function bindSession(tokenHash,hostUserId,principal,now=Date.now()){
  assertActive();if(!config.enabled||!/^[a-f0-9]{64}$/.test(tokenHash)||!hostUserId||principal?.authSource!=='developer_token'||principal.generation!==generation)throw new AuthError('SESSION_BINDING_INVALID',403);
  db.prepare('DELETE FROM oak_developer_sessions WHERE expires_at<=?').run(now);
  db.prepare('INSERT INTO oak_developer_sessions VALUES(?,?,?,?,?)').run(tokenHash,String(hostUserId),generation,now,now+8*3600_000);
 }
 function session(tokenHash,hostUserId,now=Date.now()){
  assertActive();if(!config.enabled)return null;
  const row=db.prepare('SELECT * FROM oak_developer_sessions WHERE token_hash=? AND generation=? AND expires_at>?').get(tokenHash,generation,now);
  if(!row||(hostUserId!==undefined&&row.host_user_id!==String(hostUserId)))return null;
  return {authSource:'developer_token',issuer:config.issuer,subject:config.subject,name:'Developer Token',superAdmin:true,hostUserId:row.host_user_id,authenticatedAt:row.authenticated_at,generation};
 }
 return {config,generation,assertActive,authenticate,bindSession,session};
}
function invalidateDeveloperGeneration(db,config,now=Date.now()){
 install(db);return tx(db,()=>{const state=db.prepare('SELECT * FROM oak_developer_state WHERE id=1').get();if(!state)throw new AuthError('DEVELOPER_INITIALIZATION_REQUIRED',503);
  if(state.app_id!==config.appId||state.deployment_id!==config.deploymentId)throw new AuthError('DEVELOPER_STORE_MISMATCH',503);
  const generation=randomBytes(24).toString('hex');db.prepare('UPDATE oak_developer_state SET generation=?,activated_at=? WHERE id=1').run(generation,now);db.prepare('DELETE FROM oak_developer_sessions').run();return {generation};
 });
}
module.exports={developerTokenConfigFromEnv,activateDeveloperToken,attachDeveloperToken,invalidateDeveloperGeneration};
