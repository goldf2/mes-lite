import type { ReactElement } from 'react';
export function CredentialForm(props:{endpoint:string;title?:string;description?:string;next?:string}):ReactElement;
export function AccountSettings(props:{mode:'basic'|'builtin'|'casdoor';manager:boolean;accountEndpoint:string;passwordEndpoint:string;home?:string;title?:string;embedded?:boolean}):ReactElement;
