'use client';
'use strict';
const React=require('react');
const {useEffect,useState}=React,h=React.createElement;
const errors={
 INVALID_CREDENTIALS:'访问密钥不正确。',LOGIN_RATE_LIMITED:'尝试次数过多，请稍后重试。',LOGIN_METHOD_DISABLED:'管理员登录未启用。',
 AUTH_CONFIG_FORBIDDEN:'当前账号没有认证配置管理权限。',RECENT_LOGIN_REQUIRED:'请重新登录后再修改身份服务。',
 CASDOOR_CONFIG_CONFLICT:'认证配置已变化，请刷新后重试。',CASDOOR_CONFIG_NOT_VERIFIED:'请先完成连接检查和真实测试登录。',
 CASDOOR_TEST_CONTEXT_REQUIRED:'测试证明不属于当前管理会话，请重新测试登录。',CONFIG_ENCRYPTION_KEY_REQUIRED:'部署侧尚未配置认证配置加密密钥。',
 CASDOOR_CONFIG_KEY_MISMATCH:'认证配置密钥不匹配，请恢复正确的配置密钥。'
};
function message(code){return errors[code]||code||'操作失败';}
async function request(endpoint,init){
 const response=await fetch(endpoint,{cache:'no-store',...init,headers:{'Content-Type':'application/json',...(init?.headers||{})}});
 const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(message(data.error));return data;
}
function field(label,name,type='text',props={}){return h('label',{className:'oak-auth-label'},label,h('input',{className:'oak-auth-input',name,type,...props}));}
function AdminTokenForm({endpoint,next='/',title='超管登录',description='使用本应用的管理员凭据进入管理功能。',buttonLabel='以超级管理员登录',tokenLabel='管理员 Token',placeholder,embedded=false}){
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[ready,setReady]=useState(false);useEffect(()=>setReady(true),[]);
 async function submit(event){event.preventDefault();if(busy||!ready)return;setBusy(true);setError('');try{const form=new FormData(event.currentTarget),data=await request(endpoint,{method:'POST',body:JSON.stringify({token:form.get('token'),next})});location.assign(data.next||next);}catch(e){setError(e.message);setBusy(false)}}
 const form=h('form',{method:'post',action:endpoint,onSubmit:submit,className:'oak-auth-form'},field(tokenLabel,'token','password',{required:true,maxLength:4096,autoComplete:'current-password',placeholder}),error&&h('p',{role:'alert',className:'oak-auth-error'},error),h('button',{type:'submit',className:'oak-auth-button',disabled:busy||!ready},busy?'正在验证…':buttonLabel));
 return embedded?form:h('section',{className:'oak-auth-card'},title&&h('h2',null,title),description&&h('p',{className:'oak-auth-muted'},description),form);
}
const DeveloperTokenForm=AdminTokenForm;
function AdminModePanel({endpoint='/api/auth/admin-elevation',exitEndpoint='/api/auth/admin-exit',elevated=false,next='/',title='管理员模式'}){
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[ready,setReady]=useState(false);useEffect(()=>setReady(true),[]);
 async function enter(event){event.preventDefault();if(busy||!ready)return;setBusy(true);setError('');try{const form=new FormData(event.currentTarget),data=await request(endpoint,{method:'POST',body:JSON.stringify({token:form.get('token'),next})});location.assign(data.next||next)}catch(e){setError(e.message);setBusy(false)}}
 async function leave(){if(busy)return;setBusy(true);setError('');try{const data=await request(exitEndpoint,{method:'POST',body:'{}'});location.assign(data.next||next)}catch(e){setError(e.message);setBusy(false)}}
 return h('section',{className:'oak-auth-card'},h('h2',null,title),
  elevated?h(React.Fragment,null,h('p',{className:'oak-auth-muted'},'当前账号已临时获得本应用管理员权限；退出管理员模式后恢复原权限。'),error&&h('p',{role:'alert',className:'oak-auth-error'},error),h('button',{type:'button',className:'oak-auth-secondary',disabled:busy,onClick:()=>void leave()},busy?'正在处理…':'退出管理员模式'))
  :h(React.Fragment,null,h('p',{className:'oak-auth-muted'},'输入本应用的管理员凭据，临时进入管理员模式。'),h('form',{method:'post',action:endpoint,onSubmit:enter,className:'oak-auth-form'},field('管理员 Token','token','password',{required:true,maxLength:4096,autoComplete:'current-password'}),error&&h('p',{role:'alert',className:'oak-auth-error'},error),h('button',{type:'submit',className:'oak-auth-button',disabled:busy||!ready},busy?'正在验证…':'进入管理员模式'))));
}
function CasdoorConfigPanel({endpoint,title='Casdoor 连接配置',returnHref='/settings/auth',embedded=false}){
 const [status,setStatus]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const load=async()=>setStatus(await request(endpoint));
 useEffect(()=>{let live=true;request(endpoint).then(v=>live&&setStatus(v)).catch(e=>live&&setError(e.message));return()=>{live=false}},[endpoint]);
 async function run(fn){if(busy)return;setBusy(true);setError('');setNotice('');try{await fn()}catch(e){setError(e.message)}finally{setBusy(false)}}
 async function save(event){event.preventDefault();const form=new FormData(event.currentTarget);await run(async()=>{await request(endpoint,{method:'POST',body:JSON.stringify({action:'save-draft',expectedRevision:status.draftRevision,expectedGeneration:status.authGeneration,fields:{issuer:form.get('issuer'),clientId:form.get('clientId'),application:form.get('application'),organization:form.get('organization'),discoveryUrl:form.get('discoveryUrl'),scopes:form.get('scopes')},secretAction:form.get('secretAction'),clientSecret:form.get('clientSecret')})});await load();setNotice('草稿已保存；当前正式登录配置未改变。')})}
 const draft=status?.draft||status?.active||{};
 const action=(name,payload={})=>run(async()=>{const data=await request(endpoint,{method:'POST',body:JSON.stringify({action:name,revision:status.draftRevision,generation:status.authGeneration,...payload})});if(data.authorizationUrl){location.assign(data.authorizationUrl);return}if(data.reauthenticationRequired){location.assign('/login?configurationChanged=1');return}await load();setNotice(data.message||'操作完成。')});
 return h(embedded?'section':'main',{className:'oak-auth-settings'},h('a',{href:returnHref},'← 返回账号与登录'),h(embedded?'h2':'h1',null,title),error&&h('p',{role:'alert',className:'oak-auth-error'},error),notice&&h('p',{role:'status'},notice),
  !status?h('p',{className:'oak-auth-muted'},'正在读取配置…'):h(React.Fragment,null,
   h('section',{className:'oak-auth-card'},h('h2',null,'当前状态'),h('p',{className:'oak-auth-muted'},'APP_LOGIN_MODE 仍由部署环境选择；本页只管理连接哪一套 Casdoor。'),
    h('dl',{className:'oak-auth-summary'},h('div',null,h('dt',null,'来源'),h('dd',null,status.source)),h('div',null,h('dt',null,'草稿修订'),h('dd',null,status.draftRevision||'无')),h('div',null,h('dt',null,'生效修订'),h('dd',null,status.activeRevision||'无')),h('div',null,h('dt',null,'回调地址'),h('dd',null,h('code',null,status.callbackUrl))),h('div',null,h('dt',null,'加密存储'),h('dd',null,status.encryptionReady?'已就绪':'未配置')))),
   status.source==='environment'&&h('section',{className:'oak-auth-card'},h('h2',null,'环境配置'),h('p',{className:'oak-auth-muted'},'旧 CASDOOR_* 当前只读。需要切换为页面管理时，先整份导入、检查、测试并采用。'),h('button',{type:'button',className:'oak-auth-secondary',disabled:busy||!status.encryptionReady,onClick:()=>void action('import-environment')},'导入为草稿')),
   h('section',{className:'oak-auth-card'},h('h2',null,'连接参数'),h('form',{method:'post',action:endpoint,onSubmit:save,className:'oak-auth-form'},
    field('Issuer / Casdoor 地址','issuer','url',{required:true,defaultValue:draft.issuer||''}),field('Client ID','clientId','text',{required:true,defaultValue:draft.clientId||''}),
    field('Application（可选）','application','text',{defaultValue:draft.application||''}),field('Organization（可选）','organization','text',{defaultValue:draft.organization||''}),
    field('Discovery URL（可选）','discoveryUrl','url',{defaultValue:draft.discoveryUrl||''}),field('Scopes','scopes','text',{required:true,defaultValue:draft.scopes||'openid profile email'}),
    h('label',{className:'oak-auth-label'},'Client Secret 操作',h('select',{className:'oak-auth-input',name:'secretAction',defaultValue:draft.secretConfigured?'keep':'replace'},h('option',{value:'keep'},'保留已保存密钥'),h('option',{value:'replace'},'替换密钥'),h('option',{value:'clear'},'清除密钥'))),
    field('Client Secret','clientSecret','password',{placeholder:draft.secretConfigured?'已配置；保留时留空':'请输入 Client Secret',autoComplete:'new-password',maxLength:4096}),
    h('button',{type:'submit',className:'oak-auth-button',disabled:busy||!status.encryptionReady},busy?'正在处理…':'保存草稿'))),
   status.draftRevision&&h('section',{className:'oak-auth-card'},h('h2',null,'验证与采用'),h('p',{className:'oak-auth-muted'},'检查连接只验证网络和元数据；测试登录必须走完整授权码回调，并绑定当前管理会话。'),
    h('div',{className:'oak-auth-actions'},h('button',{type:'button',className:'oak-auth-secondary',disabled:busy,onClick:()=>void action('check')},status.check?.status==='passed'?'重新检查连接':'检查连接'),h('button',{type:'button',className:'oak-auth-secondary',disabled:busy||status.check?.status!=='passed',onClick:()=>void action('begin-test')},status.test?.status==='passed'?'重新测试登录':'测试登录'),h('button',{type:'button',className:'oak-auth-button',disabled:busy||status.check?.status!=='passed'||status.test?.status!=='passed',onClick:()=>{if(confirm('采用新身份配置会使现有登录会话失效，是否继续？'))void action('activate',{contextId:status.contextId})}},'采用已验证配置')),
    h('p',{className:'oak-auth-muted'},'连接检查：'+(status.check?.status||'unverified')+'；测试登录：'+(status.test?.status||'unverified')))
  ));
}
module.exports={AdminTokenForm,AdminModePanel,DeveloperTokenForm,CasdoorConfigPanel};
