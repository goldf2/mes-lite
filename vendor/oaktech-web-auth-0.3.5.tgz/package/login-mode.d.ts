export type LoginMode='token'|'casdoor'|'builtin'|'basic'|'local';
export function loginModeFromEnv(env?:Record<string,string|undefined>,legacyDefault?:'token'|'casdoor'|'local'):LoginMode;
export function standardLoginConfigured(env?:Record<string,string|undefined>):boolean;
