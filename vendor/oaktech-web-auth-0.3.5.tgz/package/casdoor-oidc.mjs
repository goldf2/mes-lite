import https from 'node:https';
import {lookup as dnsLookup} from 'node:dns/promises';
import {isIP} from 'node:net';
import {createHash} from 'node:crypto';
import * as oidc from 'openid-client';

const hash=value=>createHash('sha256').update(String(value)).digest('hex');
function normalizeIp(value){return typeof value==='string'&&value.startsWith('::ffff:')?value.slice(7):value}
function privateIp(address){
 address=normalizeIp(address);
 if(isIP(address)===4){
  const p=address.split('.').map(Number);
  return p[0]===0||p[0]===10||p[0]===127||p[0]>=224||p[0]===169&&p[1]===254||
   p[0]===172&&p[1]>=16&&p[1]<=31||p[0]===192&&p[1]===168||
   p[0]===100&&p[1]>=64&&p[1]<=127||p[0]===198&&(p[1]===18||p[1]===19);
 }
 if(isIP(address)===6){
  const a=address.toLowerCase();return a==='::'||a==='::1'||a.startsWith('fc')||a.startsWith('fd')||
   /^fe[89ab]/.test(a)||a.startsWith('ff')||a.startsWith('2001:db8:');
 }
 return true;
}
function allowedTargets(value){
 if(value===undefined||value===null||value==='')return new Map();
 let items;try{items=typeof value==='string'?JSON.parse(value):value}catch{throw new Error('OIDC_NETWORK_POLICY_INVALID')}
 if(!Array.isArray(items)||items.length>32)throw new Error('OIDC_NETWORK_POLICY_INVALID');
 const map=new Map();
 for(const item of items){
  if(!item||typeof item!=='object'||typeof item.origin!=='string'||!Array.isArray(item.addresses)||item.addresses.length<1||item.addresses.length>32)throw new Error('OIDC_NETWORK_POLICY_INVALID');
  let url;try{url=new URL(item.origin)}catch{throw new Error('OIDC_NETWORK_POLICY_INVALID')}
  if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw new Error('OIDC_NETWORK_POLICY_INVALID');
  const addresses=new Set(item.addresses.map(normalizeIp));if([...addresses].some(a=>!isIP(a)))throw new Error('OIDC_NETWORK_POLICY_INVALID');
  map.set(url.origin,addresses);
 }
 return map;
}
async function resolveTarget(raw,{resolver=dnsLookup,allow=allowedTargets(process.env.APP_AUTH_ALLOWED_TARGETS)}={}){
 const url=raw instanceof URL?new URL(raw):new URL(String(raw));
 if(url.protocol!=='https:'||url.username||url.password||url.hash)throw new Error('OIDC_NETWORK_TARGET_DENIED');
 const explicit=allow.get(url.origin),port=url.port||'443';
 if(!explicit&&port!=='443')throw new Error('OIDC_NETWORK_TARGET_DENIED');
 let records;
 if(isIP(url.hostname))records=[{address:normalizeIp(url.hostname),family:isIP(url.hostname)}];
 else records=await resolver(url.hostname,{all:true,verbatim:true});
 const addresses=[...new Set((records||[]).map(r=>normalizeIp(r.address)).filter(Boolean))];
 if(!addresses.length)throw new Error('OIDC_NETWORK_TARGET_DENIED');
 if(explicit){
  if(addresses.some(a=>!explicit.has(a)))throw new Error('OIDC_NETWORK_TARGET_DENIED');
 }else if(addresses.some(privateIp))throw new Error('OIDC_NETWORK_TARGET_DENIED');
 return {url,addresses};
}
function bytes(body){
 if(body===undefined||body===null)return null;
 if(typeof body==='string')return Buffer.from(body);
 if(body instanceof URLSearchParams)return Buffer.from(body.toString());
 if(body instanceof ArrayBuffer)return Buffer.from(body);
 if(ArrayBuffer.isView(body))return Buffer.from(body.buffer,body.byteOffset,body.byteLength);
 throw new Error('OIDC_REQUEST_BODY_UNSUPPORTED');
}
function requestHeaders(value){
 const out={};const h=new Headers(value||{});for(const [k,v] of h.entries())out[k]=v;return out;
}
export function createSecureOidcFetch(options={}){
 const resolver=options.resolver||dnsLookup,allow=allowedTargets(options.allowedTargets??process.env.APP_AUTH_ALLOWED_TARGETS),timeoutMs=options.timeoutMs||5000,maxBytes=options.maxBytes||256*1024,testFetcher=options.fetcher;
 return async function secureFetch(raw,init={}){
  const target=await resolveTarget(raw,{resolver,allow});
  if(testFetcher){
   const response=await testFetcher(target.url.href,{...init,redirect:'manual',signal:AbortSignal.timeout(timeoutMs)});
   if(response.status>=300&&response.status<400)throw new Error('OIDC_REDIRECT_DENIED');
   const data=Buffer.from(await response.arrayBuffer());if(data.length>maxBytes)throw new Error('OIDC_RESPONSE_TOO_LARGE');
   return new Response(data,{status:response.status,statusText:response.statusText,headers:response.headers});
  }
  const body=bytes(init.body),headers=requestHeaders(init.headers);headers.host=target.url.host;if(body&&!Object.keys(headers).some(k=>k.toLowerCase()==='content-length'))headers['content-length']=String(body.length);
  const address=target.addresses[0];
  return await new Promise((resolve,reject)=>{
   let settled=false;const fail=e=>{if(!settled){settled=true;reject(e)}};const chunks=[];let size=0;
   const req=https.request({hostname:address,port:Number(target.url.port||443),servername:target.url.hostname,path:target.url.pathname+target.url.search,method:init.method||'GET',headers,rejectUnauthorized:true,agent:false,timeout:timeoutMs},res=>{
    const remote=normalizeIp(res.socket.remoteAddress||'');if(!target.addresses.includes(remote)){res.destroy();return fail(new Error('OIDC_NETWORK_TARGET_CHANGED'))}
    if((res.statusCode||0)>=300&&(res.statusCode||0)<400){res.destroy();return fail(new Error('OIDC_REDIRECT_DENIED'))}
    res.on('data',chunk=>{size+=chunk.length;if(size>maxBytes){req.destroy();fail(new Error('OIDC_RESPONSE_TOO_LARGE'));return}chunks.push(chunk)});
    res.on('end',()=>{if(settled)return;settled=true;resolve(new Response(Buffer.concat(chunks),{status:res.statusCode||502,statusText:res.statusMessage||'',headers:res.headers}))});
   });
   req.on('timeout',()=>req.destroy(new Error('OIDC_REQUEST_TIMEOUT')));req.on('error',fail);
   if(init.signal){if(init.signal.aborted)req.destroy(init.signal.reason);else init.signal.addEventListener('abort',()=>req.destroy(init.signal.reason),{once:true})}
   if(body)req.write(body);req.end();
  });
 };
}
async function discover(settings,network={}){
 const secureFetch=createSecureOidcFetch(network);let config;
 if(settings.discoveryUrl){
  const d=new URL(settings.discoveryUrl),issuer=new URL(settings.issuer);if(d.origin!==issuer.origin)throw new Error('OIDC_DISCOVERY_ORIGIN_MISMATCH');
  const response=await secureFetch(d.href,{headers:{accept:'application/json'}});if(!response.ok)throw new Error('OIDC_DISCOVERY_FAILED');
  const metadata=await response.json();if(!metadata||metadata.issuer!==settings.issuer)throw new Error('OIDC_ISSUER_MISMATCH');
  config=new oidc.Configuration(metadata,settings.clientId,settings.clientSecret);config[oidc.customFetch]=secureFetch;oidc.enableNonRepudiationChecks(config);
 }else{
  config=await oidc.discovery(new URL(settings.issuer),settings.clientId,settings.clientSecret,undefined,{[oidc.customFetch]:secureFetch,timeout:Math.max(1,Math.ceil((network.timeoutMs||5000)/1000)),execute:[oidc.enableNonRepudiationChecks]});
 }
 const metadata=config.serverMetadata();if(metadata.issuer!==settings.issuer)throw new Error('OIDC_ISSUER_MISMATCH');
 return {config,metadata,secureFetch};
}
export async function checkCasdoorConnection(store,{revision,generation,actor='configuration-admin',network={}}){
 try{
  const settings=store.readDraft(revision),{metadata,secureFetch}=await discover(settings,network);
  for(const key of ['authorization_endpoint','token_endpoint','jwks_uri'])if(typeof metadata[key]!=='string'||!metadata[key])throw new Error('OIDC_DISCOVERY_INCOMPLETE');
  if(Array.isArray(metadata.response_types_supported)&&!metadata.response_types_supported.includes('code'))throw new Error('OIDC_CODE_FLOW_UNSUPPORTED');
  if(Array.isArray(metadata.code_challenge_methods_supported)&&!metadata.code_challenge_methods_supported.includes('S256'))throw new Error('OIDC_PKCE_UNSUPPORTED');
  const jwks=await secureFetch(metadata.jwks_uri,{headers:{accept:'application/json'}});if(!jwks.ok)throw new Error('OIDC_JWKS_UNAVAILABLE');
  const keys=await jwks.json();if(!keys||!Array.isArray(keys.keys)||!keys.keys.length)throw new Error('OIDC_JWKS_INVALID');
  store.recordCheck(revision,generation,true,'OK',actor);
  return {issuer:metadata.issuer,authorizationEndpoint:metadata.authorization_endpoint,tokenEndpoint:metadata.token_endpoint,jwksUri:metadata.jwks_uri,userinfoEndpoint:metadata.userinfo_endpoint||null,endSessionEndpoint:metadata.end_session_endpoint||null};
 }catch(error){
  try{store.recordCheck(revision,generation,false,String(error?.message||'OIDC_CHECK_FAILED').slice(0,80),actor)}catch{}
  throw error;
 }
}
export async function beginCasdoorTestLogin(store,{revision,generation,contextId,actor='configuration-admin',network={}}){
 const settings=store.readDraft(revision),{config}=await discover(settings,network);
 const verifier=oidc.randomPKCECodeVerifier(),state=oidc.randomState(),nonce=oidc.randomNonce();
 const pending=store.createTestState(revision,generation,contextId,{verifier,state,nonce});
 const url=oidc.buildAuthorizationUrl(config,{redirect_uri:store.callbackUrl,scope:settings.scopes||'openid profile email',code_challenge:await oidc.calculatePKCECodeChallenge(verifier),code_challenge_method:'S256',state,nonce,prompt:'login',max_age:'0'});
 return {...pending,authorizationUrl:url.href};
}
export async function completeCasdoorTestLogin(store,{ticket,contextId,requestUrl,actor='configuration-admin',network={},assertContext=()=>{}}){
 const pending=store.consumeTestState(ticket,contextId),settings=store.readDraft(pending.revision);
 try{
  const expected=new URL(store.callbackUrl),incoming=new URL(requestUrl);if(incoming.origin!==expected.origin||incoming.pathname!==expected.pathname)throw new Error('OIDC_CALLBACK_MISMATCH');
  const {config}=await discover(settings,network);expected.search=incoming.search;
  const tokens=await oidc.authorizationCodeGrant(config,expected,{pkceCodeVerifier:pending.verifier,expectedState:pending.state,expectedNonce:pending.nonce,idTokenExpected:true});
  const claims=tokens.claims();if(!claims?.sub||claims.iss!==settings.issuer)throw new Error('OIDC_TEST_IDENTITY_INVALID');
  assertContext();store.recordTest(pending.revision,pending.generation,contextId,true,'OK',actor);
  return {revision:pending.revision,identityHash:hash(settings.issuer+'\0'+claims.sub)};
 }catch(error){
  try{assertContext();store.recordTest(pending.revision,pending.generation,contextId,false,String(error?.message||'OIDC_TEST_FAILED').slice(0,80),actor)}catch{}
  throw error;
 }
}
export async function createCasdoorOidcConfiguration(settings,network={}){return (await discover(settings,network)).config}
