import type {CasdoorConfigStore,CasdoorConnection} from './casdoor-config';
export interface OidcNetworkOptions {allowedTargets?:string|unknown[];timeoutMs?:number;maxBytes?:number;resolver?:any;fetcher?:typeof fetch}
export function createSecureOidcFetch(options?:OidcNetworkOptions):(url:string|URL,init?:RequestInit)=>Promise<Response>;
export function checkCasdoorConnection(store:CasdoorConfigStore,input:{revision:string;generation:number;actor?:string;network?:OidcNetworkOptions}):Promise<Record<string,unknown>>;
export function beginCasdoorTestLogin(store:CasdoorConfigStore,input:{revision:string;generation:number;contextId:string;actor?:string;network?:OidcNetworkOptions}):Promise<{ticket:string;revision:string;generation:number;contextId:string;expiresAt:number;authorizationUrl:string}>;
export function completeCasdoorTestLogin(store:CasdoorConfigStore,input:{ticket:string;contextId:string;requestUrl:string;actor?:string;network?:OidcNetworkOptions;assertContext?:()=>void}):Promise<{revision:string;identityHash:string}>;
export function createCasdoorOidcConfiguration(settings:CasdoorConnection,network?:OidcNetworkOptions):Promise<any>;
