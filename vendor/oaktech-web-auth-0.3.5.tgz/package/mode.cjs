'use strict';
// Pure configuration selection; does not pull crypto/database code into clients.
const MODES = new Set(['basic', 'builtin', 'casdoor']);
class AuthError extends Error {
  constructor(code, status = 400) { super(code); this.name = 'AuthError'; this.code = code; this.status = status; }
}
function modeFromEnv(env = process.env, legacyDefault = 'casdoor') {
  const raw = env.APP_AUTH_MODE;
  if (raw === undefined) {
    if (env.AUTH_MODE && !['local', 'casdoor'].includes(env.AUTH_MODE)) throw new AuthError('AUTH_MODE_INVALID', 503);
    return env.AUTH_MODE || legacyDefault;
  }
  if (!MODES.has(raw)) throw new AuthError('AUTH_MODE_INVALID', 503);
  if (env.AUTH_MODE !== undefined && env.AUTH_MODE !== raw) throw new AuthError('AUTH_MODE_CONFLICT', 503);
  return raw;
}
module.exports = { AuthError, modeFromEnv };
