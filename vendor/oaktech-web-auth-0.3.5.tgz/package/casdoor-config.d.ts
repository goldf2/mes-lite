import type {AuthDatabase,AuthConfig} from './index';
export interface SecretCodec {keyId:string;encrypt(value:string,aad:string):string;decrypt(value:string,aad:string):string}
export interface CasdoorConnection {issuer:string;clientId:string;clientSecret:string;application:string;organization:string;discoveryUrl:string;scopes:string}
export interface CasdoorStoreOptions {appId:string;origin:string;callbackPath:string;codec?:SecretCodec|null;env?:Record<string,string|undefined>}
export interface CasdoorState {deploymentId:string;source:'none'|'environment'|'database';draftRevision:string|null;activeRevision:string|null;authGeneration:number;runtimeMode:string|null}
export interface CasdoorConfigStore {
 readonly appId:string;readonly deploymentId:string;readonly origin:string;readonly callbackUrl:string;
 state():CasdoorState;redacted(mode:string):any;active():CasdoorConnection|null;readDraft(revision:string):CasdoorConnection;
 beginRuntime(mode:'token'|'basic'|'builtin'|'casdoor'):CasdoorState;
 saveDraft(expectedRevision:string|null,fields:Record<string,unknown>,secretAction?:'keep'|'replace'|'clear',secretValue?:string,actor?:string,expectedGeneration?:number):any;
 importEnvironment(expectedRevision:string|null,actor?:string,expectedGeneration?:number):any;
 recordCheck(revision:string,generation:number,success:boolean,code?:string,actor?:string):any;
 recordTest(revision:string,generation:number,contextId:string,success?:boolean,code?:string,actor?:string):any;
 createTestState(revision:string,generation:number,contextId:string,data:{verifier:string;state:string;nonce:string},now?:number):{ticket:string;revision:string;generation:number;contextId:string;expiresAt:number};
 consumeTestState(ticket:string,contextId:string,now?:number):any;
 activate(expectedRevision:string,actor:string,contextId:string):{activeRevision:string;state:CasdoorState;config:CasdoorConnection};
}
export function createAesGcmCodec(rawKey:string):SecretCodec;
export function createCasdoorConfigStore(db:AuthDatabase,options:CasdoorStoreOptions):CasdoorConfigStore;
export function effectiveAuthConfig(db:AuthDatabase,options:CasdoorStoreOptions&{legacyDefault?:'local'|'casdoor'|'token'},env?:Record<string,string|undefined>):AuthConfig;
export function environmentConfig(env:Record<string,string|undefined>):CasdoorConnection|null;
export function validateFields(input:Record<string,unknown>):Omit<CasdoorConnection,'clientSecret'>;
