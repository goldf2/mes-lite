export type AuthMode = 'basic' | 'builtin' | 'casdoor';
export type SqlValue = string | number | null;
export interface AuthDatabase {
  exec(sql: string): unknown;
  prepare(sql: string): {
    /** Drivers have different generic/named binding overloads; query values are validated internally. */
    get(...args: any[]): unknown;
    all(...args: any[]): unknown[];
    run(...args: any[]): unknown;
  };
}
export interface AuthConfig {
  readonly appId: string;
  readonly mode: AuthMode;
  readonly origin: string;
  readonly basicUsername?: string;
  readonly basicPassword?: string;
  readonly issuer?: string;
  readonly clientId?: string;
  readonly clientSecret?: string;
}
export interface Principal {
  mode: AuthMode; subject: string; name: string; manager: boolean;
  credentialRevision: number; authenticatedAt?: number; generation: string;
}
export interface AuthSession {
  mode: AuthMode; subject: string; manager: boolean; hostUserId: string;
  authenticatedAt: number; generation: string;
}
export interface BuiltinUser {
  id: string; username: string; name: string; disabled: boolean;
  manager: boolean; revision: number;
}
export interface AuthRuntime {
  readonly config: AuthConfig;
  readonly generation: string;
  assertActive(): void;
  authenticate(username: unknown, password: unknown, now?: number): Promise<Principal>;
  bindSession(tokenHash: string, hostUserId: string, principal: Principal, now?: number): void;
  session(tokenHash: string, hostUserId?: string, now?: number): AuthSession | null;
  requireManager(tokenHash: string, hostUserId: string, now?: number): AuthSession;
  challenge(tokenHash: string, now?: number): void;
  consumeChallenge(tokenHash: string, now?: number): string;
  externalPrincipal(issuer: string, subject: unknown, name: string, authenticatedAt?: number): Principal;
}
export class AuthError extends Error { readonly code: string; readonly status: number; constructor(code: string, status?: number); }
export function modeFromEnv(env?: Record<string, string | undefined>, legacyDefault?: 'local' | 'casdoor'): AuthMode | 'local';
export function configFromEnv(appId: string, env?: Record<string, string | undefined>): AuthConfig;
export function configuredState(db: AuthDatabase): {app_id: string; mode: AuthMode; generation: string; schema_version: number} | null;
export function activate(db: AuthDatabase, config: AuthConfig, now?: number): {changed: boolean; generation: string; mode: AuthMode};
export function suspendExternalAuth(db: AuthDatabase, appId: string, mode?: 'casdoor', now?: number): {changed: boolean; generation: string; mode: 'casdoor'};
export function attach(db: AuthDatabase, config: AuthConfig): AuthRuntime;
export function createUser(db: AuthDatabase, input: {username: unknown; name: unknown; password: unknown; manager?: boolean}, actor?: string, authorize?: () => void): Promise<BuiltinUser>;
export function listUsers(db: AuthDatabase): BuiltinUser[];
export function resetPassword(db: AuthDatabase, id: string, password: unknown, expectedRevision: number, actor?: string, authorize?: () => void): Promise<BuiltinUser>;
export function setDisabled(db: AuthDatabase, id: string, disabled: boolean, expectedRevision: number, actor?: string, authorize?: () => void): BuiltinUser;
export function hashPassword(password: unknown): Promise<string>;
export function verifyPassword(password: unknown, encoded: unknown): Promise<boolean>;
export function localIssuer(appId: string, mode: 'basic' | 'builtin'): string;
export function digest(value: string): string;
