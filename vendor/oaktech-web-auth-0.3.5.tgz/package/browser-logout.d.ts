/** Requires trusted issuer origin and completed local revocation. Never navigates. */
export declare function logoutCasdoorBrowser(issuerOrigin: string, fetcher?: typeof fetch): Promise<{confirmed: true}>;
