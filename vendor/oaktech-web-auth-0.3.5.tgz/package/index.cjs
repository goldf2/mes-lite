'use strict';
// Server-only package. Hosts keep their own business roles, data scopes and session tables.
const { randomBytes, randomUUID, createHash, scrypt, scryptSync, timingSafeEqual } = require('node:crypto');
const { AuthError, modeFromEnv } = require('./mode.cjs');
// OWASP scrypt memory/CPU trade-off: N=2^15, r=8, p=3. No plaintext password storage.
const SCRYPT = Object.freeze({ N: 32768, r: 8, p: 3, maxmem: 64 * 1024 * 1024 });
const PASSWORD_TAG = 'scrypt-32768-8-3';
const SESSION_MS = 8 * 3600_000;
const fingerprintCache = new Map();
let runningKdfs = 0;
function digest(value) { return createHash('sha256').update(value).digest('hex'); }
function constantEqual(a, b) { return timingSafeEqual(createHash('sha256').update(a).digest(), createHash('sha256').update(b).digest()); }
function username(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.@+-]{2,79}$/.test(value)) throw new AuthError('INVALID_USERNAME');
  return value.toLowerCase();
}
function password(value) {
  if (typeof value !== 'string' || [...value].length < 15 || Buffer.byteLength(value, 'utf8') > 1024) throw new AuthError('PASSWORD_LENGTH');
  return value;
}
function displayName(value) {
  if (typeof value !== 'string' || !value.trim() || value.length > 160) throw new AuthError('INVALID_NAME');
  return value.trim();
}
function configFromEnv(appId, env = process.env) {
  if (!/^[a-z][a-z0-9-]{2,79}$/.test(appId)) throw new AuthError('APP_ID_INVALID', 503);
  if (env.APP_AUTH_MODE === undefined) throw new AuthError('APP_AUTH_MODE_REQUIRED', 503);
  const mode = modeFromEnv(env);
  const origin = env.APP_ORIGIN;
  let parsed;
  try { parsed = new URL(origin); } catch { throw new AuthError('APP_ORIGIN_INVALID', 503); }
  if (parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/' ||
      !(parsed.protocol === 'https:' || parsed.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname))) {
    throw new AuthError('APP_ORIGIN_INVALID', 503);
  }
  if (mode !== 'casdoor' && ['SAAS_ENABLED', 'SAAS_COMMERCE_ENABLED', 'CASDOOR_RBAC_ENABLED'].some(k => env[k] === 'true')) {
    throw new AuthError('LOCAL_MODE_CENTRAL_DEPENDENCY_CONFLICT', 503);
  }
  const config = { appId, mode, origin: parsed.origin };
  if (mode === 'basic') {
    try { config.basicUsername = username(env.APP_BASIC_USERNAME); config.basicPassword = password(env.APP_BASIC_PASSWORD); }
    catch { throw new AuthError('BASIC_CREDENTIALS_REQUIRED', 503); }
  }
  if (mode === 'casdoor') {
    try {
      const issuer = new URL(env.CASDOOR_ISSUER);
      if (issuer.protocol !== 'https:' || issuer.username || issuer.password || issuer.search || issuer.hash) throw new Error();
      if (typeof env.CASDOOR_CLIENT_ID !== 'string' || !env.CASDOOR_CLIENT_ID.trim() || env.CASDOOR_CLIENT_ID.length > 512 ||
          typeof env.CASDOOR_CLIENT_SECRET !== 'string' || !env.CASDOOR_CLIENT_SECRET || env.CASDOOR_CLIENT_SECRET.length > 4096) throw new Error();
      config.issuer = env.CASDOOR_ISSUER; config.clientId = env.CASDOOR_CLIENT_ID; config.clientSecret = env.CASDOOR_CLIENT_SECRET;
    } catch { throw new AuthError('CASDOOR_CONFIGURATION_REQUIRED', 503); }
  }
  return Object.freeze(config);
}
function transaction(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const result = fn(); db.exec('COMMIT'); return result; }
  catch (error) { db.exec('ROLLBACK'); throw error; }
}
function installSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS oak_auth_state (
      id INTEGER PRIMARY KEY CHECK(id=1), schema_version INTEGER NOT NULL,
      app_id TEXT NOT NULL, mode TEXT NOT NULL, generation TEXT NOT NULL,
      salt TEXT NOT NULL, fingerprint TEXT NOT NULL, activated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS oak_auth_users (
      id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
      password_hash TEXT NOT NULL, disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1)),
      manager INTEGER NOT NULL DEFAULT 0 CHECK(manager IN (0,1)), revision INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS oak_auth_sessions (
      token_hash TEXT PRIMARY KEY, host_user_id TEXT NOT NULL, mode TEXT NOT NULL,
      subject TEXT NOT NULL, generation TEXT NOT NULL, credential_revision INTEGER NOT NULL,
      authenticated_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS oak_auth_challenges (
      token_hash TEXT PRIMARY KEY, generation TEXT NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS oak_auth_attempts (
      bucket TEXT PRIMARY KEY, attempts INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS oak_auth_events (
      id INTEGER PRIMARY KEY, action TEXT NOT NULL, actor TEXT NOT NULL,
      subject TEXT, revision INTEGER, at INTEGER NOT NULL
    );
  `);
}
function configuredState(db) {
  if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='oak_auth_state'").get()) return null;
  return db.prepare('SELECT * FROM oak_auth_state WHERE id=1').get() || null;
}
function fingerprint(config, salt) {
  const text = JSON.stringify([config.appId, config.mode, config.origin, config.basicUsername || '', config.basicPassword || '', config.issuer || '', config.clientId || '', config.clientSecret || '']);
  const key = digest(salt + text);
  if (!fingerprintCache.has(key)) {
    // The stored generation fingerprint must not become a fast offline password oracle.
    const value = scryptSync(text, Buffer.from(salt, 'hex'), 32, SCRYPT).toString('hex');
    if (fingerprintCache.size >= 8) fingerprintCache.clear();
    fingerprintCache.set(key, value);
  }
  return fingerprintCache.get(key);
}
function event(db, action, actor, subject = null, revision = null, at = Date.now()) {
  db.prepare('INSERT INTO oak_auth_events(action,actor,subject,revision,at) VALUES(?,?,?,?,?)').run(action, actor, subject, revision, at);
}
function activate(db, config, now = Date.now()) {
  // Deployment/startup-only action. HTTP request handlers only attach/read, never activate.
  installSchema(db);
  return transaction(db, () => {
    const previous = configuredState(db);
    if (previous && (previous.schema_version !== 1 || previous.app_id !== config.appId)) throw new AuthError('AUTH_STORE_MISMATCH', 503);
    const salt = previous?.salt || randomBytes(16).toString('hex');
    const current = fingerprint(config, salt);
    if (previous && constantEqual(previous.fingerprint, current)) return { changed: false, generation: previous.generation, mode: previous.mode };
    const generation = randomBytes(24).toString('hex');
    db.prepare(`INSERT INTO oak_auth_state VALUES(1,1,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET mode=excluded.mode,generation=excluded.generation,
      fingerprint=excluded.fingerprint,activated_at=excluded.activated_at`).run(config.appId, config.mode, generation, salt, current, now);
    db.prepare('DELETE FROM oak_auth_sessions').run();
    db.prepare('DELETE FROM oak_auth_challenges').run();
    event(db, 'auth/configuration-activated', 'deployment', null, null, now);
    return { changed: true, generation, mode: config.mode };
  });
}
function suspendExternalAuth(db, appId, mode = 'casdoor', now = Date.now()) {
  if (!/^[a-z][a-z0-9-]{2,79}$/.test(appId) || mode !== 'casdoor') throw new AuthError('AUTH_SUSPEND_INVALID', 503);
  installSchema(db);
  return transaction(db, () => {
    const previous = configuredState(db);
    if (previous && (previous.schema_version !== 1 || previous.app_id !== appId)) throw new AuthError('AUTH_STORE_MISMATCH', 503);
    const generation = randomBytes(24).toString('hex'), salt = previous?.salt || randomBytes(16).toString('hex');
    db.prepare(`INSERT INTO oak_auth_state VALUES(1,1,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET mode=excluded.mode,generation=excluded.generation,
      fingerprint=excluded.fingerprint,activated_at=excluded.activated_at`).run(appId, mode, generation, salt, 'external-unavailable', now);
    db.prepare('DELETE FROM oak_auth_sessions').run();
    db.prepare('DELETE FROM oak_auth_challenges').run();
    event(db, 'auth/external-suspended', 'deployment', null, null, now);
    return { changed: true, generation, mode };
  });
}
async function derive(value, salt) {
  if (runningKdfs >= 2) throw new AuthError('AUTH_BUSY', 429);
  runningKdfs++;
  try { return await new Promise((resolve, reject) => scrypt(value, salt, 64, SCRYPT, (e, result) => e ? reject(e) : resolve(result))); }
  finally { runningKdfs--; }
}
async function hashPassword(value) {
  password(value);
  const salt = randomBytes(16).toString('hex');
  const key = await derive(value, Buffer.from(salt, 'hex'));
  return `${PASSWORD_TAG}$${salt}$${key.toString('hex')}`;
}
async function verifyPassword(value, encoded) {
  if (typeof value !== 'string' || Buffer.byteLength(value, 'utf8') > 1024) return false;
  const pieces = typeof encoded === 'string' ? encoded.split('$') : [];
  const valid = pieces.length === 3 && pieces[0] === PASSWORD_TAG && /^[a-f0-9]{32}$/.test(pieces[1]) && /^[a-f0-9]{128}$/.test(pieces[2]);
  // Unknown users and malformed hashes still pay the same KDF cost; generic errors only.
  const key = await derive(value, Buffer.from(valid ? pieces[1] : '8c6a0ab19f50cc269816408517f6974a', 'hex'));
  return timingSafeEqual(key, Buffer.from(valid ? pieces[2] : '0'.repeat(128), 'hex')) && valid;
}
function publicUser(row) {
  return { id: row.id, username: row.username, name: row.name, disabled: Boolean(row.disabled), manager: Boolean(row.manager), revision: row.revision };
}
function attach(db, config) {
  const initial = configuredState(db);
  if (!initial) throw new AuthError('AUTH_INITIALIZATION_REQUIRED', 503);
  if (initial.schema_version !== 1 || initial.app_id !== config.appId || !constantEqual(initial.fingerprint, fingerprint(config, initial.salt))) throw new AuthError('AUTH_CONFIGURATION_NOT_ACTIVE', 503);
  const generation = initial.generation;
  function assertActive() {
    const current = configuredState(db);
    if (!current || current.generation !== generation || current.mode !== config.mode) throw new AuthError('AUTH_CONFIGURATION_CHANGED', 409);
  }
  function throttle(key, now) {
    transaction(db, () => {
      assertActive();
      db.prepare('DELETE FROM oak_auth_attempts WHERE expires_at<=?').run(now);
      for (const [bucket, max, duration] of [['all', 60, 60_000], [`${config.mode}:${key}`, 8, 15 * 60_000]]) {
        const found = db.prepare('SELECT attempts FROM oak_auth_attempts WHERE bucket=?').get(bucket);
        if (found && found.attempts >= max) throw new AuthError('LOGIN_RATE_LIMITED', 429);
      }
      for (const [bucket, duration] of [['all', 60_000], [`${config.mode}:${key}`, 15 * 60_000]]) {
        db.prepare('INSERT INTO oak_auth_attempts VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET attempts=attempts+1').run(bucket, now + duration);
      }
    });
  }
  async function authenticate(name, value, now = Date.now()) {
    assertActive();
    if (!['basic', 'builtin'].includes(config.mode)) throw new AuthError('LOGIN_METHOD_DISABLED', 404);
    let key;
    try { key = username(name); } catch { key = '_invalid'; }
    throttle(digest(key), now);
    let principal;
    if (config.mode === 'basic') {
      const a = constantEqual(key, config.basicUsername);
      const b = typeof value === 'string' && Buffer.byteLength(value, 'utf8') <= 1024 && constantEqual(value, config.basicPassword);
      if (a && b) principal = { mode: 'basic', subject: 'operator', name: config.basicUsername, manager: true, credentialRevision: 0, generation };
    } else {
      const row = db.prepare('SELECT * FROM oak_auth_users WHERE username=?').get(key);
      const valid = await verifyPassword(value, row?.password_hash);
      assertActive();
      const live = row ? db.prepare('SELECT * FROM oak_auth_users WHERE id=?').get(row.id) : null;
      if (valid && live && !live.disabled && live.revision === row.revision) principal = { mode: 'builtin', subject: live.id, name: live.name, manager: Boolean(live.manager), credentialRevision: live.revision, generation };
    }
    assertActive();
    if (!principal) throw new AuthError('INVALID_CREDENTIALS', 401);
    db.prepare('DELETE FROM oak_auth_attempts WHERE bucket=?').run(`${config.mode}:${digest(key)}`);
    return principal;
  }
  function bindSession(hash, hostUserId, principal, now = Date.now()) {
    assertActive();
    if (!/^[a-f0-9]{64}$/.test(hash) || typeof hostUserId !== 'string' || !hostUserId || principal.mode !== config.mode || principal.generation !== generation) throw new AuthError('SESSION_BINDING_INVALID', 403);
    if (principal.mode === 'builtin') {
      const row = db.prepare('SELECT revision,disabled FROM oak_auth_users WHERE id=?').get(principal.subject);
      if (!row || row.disabled || row.revision !== principal.credentialRevision) throw new AuthError('INVALID_CREDENTIALS', 401);
    }
    const authenticatedAt = principal.mode === 'casdoor' ? (Number.isFinite(principal.authenticatedAt) ? principal.authenticatedAt : 0) : now;
    db.prepare('DELETE FROM oak_auth_sessions WHERE expires_at<=?').run(now);
    db.prepare('INSERT INTO oak_auth_sessions VALUES(?,?,?,?,?,?,?,?)').run(hash, hostUserId, config.mode, principal.subject, generation, principal.credentialRevision, authenticatedAt, now + SESSION_MS);
  }
  function session(hash, hostUserId, now = Date.now()) {
    assertActive();
    const row = db.prepare('SELECT * FROM oak_auth_sessions WHERE token_hash=? AND generation=? AND mode=? AND expires_at>?').get(hash, generation, config.mode, now);
    if (!row || hostUserId !== undefined && row.host_user_id !== String(hostUserId)) return null;
    let manager = config.mode === 'basic';
    if (config.mode === 'builtin') {
      const user = db.prepare('SELECT disabled,revision,manager FROM oak_auth_users WHERE id=?').get(row.subject);
      if (!user || user.disabled || user.revision !== row.credential_revision) return null;
      manager = Boolean(user.manager);
    }
    return { mode: row.mode, subject: row.subject, manager, hostUserId: row.host_user_id, authenticatedAt: row.authenticated_at, generation };
  }
  function requireManager(hash, hostUserId, now = Date.now()) {
    const user = session(hash, hostUserId, now);
    if (!user) throw new AuthError('LOGIN_REQUIRED', 401);
    if (!user.manager) throw new AuthError('AUTH_MANAGER_REQUIRED', 403);
    if (user.authenticatedAt < now - 15 * 60_000) throw new AuthError('RECENT_LOGIN_REQUIRED', 403);
    return user;
  }
  function challenge(hash, now = Date.now()) {
    assertActive();
    if (config.mode !== 'casdoor') throw new AuthError('LOGIN_METHOD_DISABLED', 404);
    db.prepare('DELETE FROM oak_auth_challenges WHERE expires_at<=?').run(now);
    db.prepare('INSERT INTO oak_auth_challenges VALUES(?,?,?)').run(hash, generation, now + 600_000);
  }
  function consumeChallenge(hash, now = Date.now()) {
    assertActive();
    return transaction(db, () => {
      const row = db.prepare('SELECT 1 FROM oak_auth_challenges WHERE token_hash=? AND generation=? AND expires_at>?').get(hash, generation, now);
      db.prepare('DELETE FROM oak_auth_challenges WHERE token_hash=?').run(hash);
      if (!row || config.mode !== 'casdoor') throw new AuthError('LOGIN_CHALLENGE_EXPIRED', 401);
      return generation;
    });
  }
  function externalPrincipal(issuer, subject, name, authenticatedAt = 0) {
    assertActive();
    if (config.mode !== 'casdoor' || issuer !== config.issuer || typeof subject !== 'string' || !subject || subject.trim() !== subject || subject.length > 512) throw new AuthError('INVALID_EXTERNAL_IDENTITY', 401);
    const authTime = Number.isFinite(authenticatedAt) && authenticatedAt > 0 ? authenticatedAt : 0;
    return { mode: 'casdoor', subject, name: displayName(name), manager: false, credentialRevision: 0, authenticatedAt: authTime, generation };
  }
  return { config, generation, assertActive, authenticate, bindSession, session, requireManager, challenge, consumeChallenge, externalPrincipal };
}
async function createUser(db, input, actor = 'deployment', authorize = () => {}) {
  authorize();
  if (!configuredState(db)) throw new AuthError('AUTH_INITIALIZATION_REQUIRED', 503);
  const key = username(input.username), name = displayName(input.name), encoded = await hashPassword(input.password);
  const id = randomUUID();
  return transaction(db, () => {
    authorize();
    if (db.prepare('SELECT 1 FROM oak_auth_users WHERE username=?').get(key)) throw new AuthError('USERNAME_EXISTS', 409);
    if (input.manager !== undefined && typeof input.manager !== 'boolean') throw new AuthError('INVALID_MANAGER_FLAG');
    db.prepare('INSERT INTO oak_auth_users(id,username,name,password_hash,manager,created_at) VALUES(?,?,?,?,?,?)').run(id, key, name, encoded, input.manager ? 1 : 0, Date.now());
    event(db, 'builtin/user-created', actor, id, 1);
    return publicUser(db.prepare('SELECT * FROM oak_auth_users WHERE id=?').get(id));
  });
}
function listUsers(db) { return db.prepare('SELECT id,username,name,disabled,manager,revision FROM oak_auth_users ORDER BY created_at,id').all().map(publicUser); }
async function resetPassword(db, id, next, expectedRevision, actor = 'deployment', authorize = () => {}) {
  authorize();
  const encoded = await hashPassword(next);
  return transaction(db, () => {
    authorize();
    const row = db.prepare('SELECT * FROM oak_auth_users WHERE id=?').get(id);
    if (!row) throw new AuthError('USER_NOT_FOUND', 404);
    if (row.revision !== expectedRevision) throw new AuthError('USER_CHANGED', 409);
    db.prepare('UPDATE oak_auth_users SET password_hash=?,revision=revision+1 WHERE id=?').run(encoded, id);
    db.prepare("DELETE FROM oak_auth_sessions WHERE mode='builtin' AND subject=?").run(id);
    event(db, 'builtin/password-reset', actor, id, row.revision + 1);
    return publicUser(db.prepare('SELECT * FROM oak_auth_users WHERE id=?').get(id));
  });
}
function setDisabled(db, id, disabled, expectedRevision, actor = 'deployment', authorize = () => {}) {
  if (typeof disabled !== 'boolean') throw new AuthError('INVALID_DISABLED_FLAG');
  return transaction(db, () => {
    authorize();
    const row = db.prepare('SELECT * FROM oak_auth_users WHERE id=?').get(id);
    if (!row) throw new AuthError('USER_NOT_FOUND', 404);
    if (row.revision !== expectedRevision) throw new AuthError('USER_CHANGED', 409);
    db.prepare('UPDATE oak_auth_users SET disabled=?,revision=revision+1 WHERE id=?').run(disabled ? 1 : 0, id);
    db.prepare("DELETE FROM oak_auth_sessions WHERE mode='builtin' AND subject=?").run(id);
    event(db, 'builtin/user-state', actor, id, row.revision + 1);
    return publicUser(db.prepare('SELECT * FROM oak_auth_users WHERE id=?').get(id));
  });
}
function localIssuer(appId, mode) {
  if (!['basic', 'builtin'].includes(mode)) throw new AuthError('LOCAL_PROVIDER_REQUIRED');
  return `urn:oaktech:${appId}:${mode}`;
}
module.exports = { AuthError, modeFromEnv, configFromEnv, configuredState, activate, suspendExternalAuth, attach, createUser, listUsers, resetPassword, setDisabled, hashPassword, verifyPassword, localIssuer, digest };
