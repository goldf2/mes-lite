'use strict';
const {AuthError}=require('./mode.cjs');
const LOCAL=/^[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]{1,64}$/;
const LABEL=/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/;
function normalizeEmail(value){
 if(typeof value!=='string')return null;value=value.trim();
 if(value.length>254||value.split('@').length!==2)return null;
 const at=value.lastIndexOf('@'),local=value.slice(0,at),domain=value.slice(at+1),labels=domain.split('.');
 if(!LOCAL.test(local)||local.startsWith('.')||local.endsWith('.')||local.includes('..')||labels.length<2||labels.some(x=>!LABEL.test(x)))return null;
 return local+'@'+domain.toLowerCase();
}
function parseSuperAdminEmails(value){
 if(value===undefined||value===null||value==='')return new Set();
 try{
  if(typeof value!=='string'||value.length>65536)throw new Error();
  const items=JSON.parse(value);if(!Array.isArray(items)||items.length>1000)throw new Error();
  const out=new Set();for(const item of items){const email=normalizeEmail(item);if(!email)throw new Error();out.add(email);}return out;
 }catch{throw new AuthError('SUPER_ADMIN_EMAILS_INVALID',503);}
}
function installAdminSchema(db){
 db.exec(`
  CREATE TABLE IF NOT EXISTS oak_auth_identity_observations(
   issuer TEXT NOT NULL,subject TEXT NOT NULL,email TEXT NOT NULL,email_verified INTEGER NOT NULL,last_seen INTEGER NOT NULL,
   PRIMARY KEY(issuer,subject));
  CREATE TABLE IF NOT EXISTS oak_auth_verified_emails(
   issuer TEXT NOT NULL,subject TEXT NOT NULL,email TEXT NOT NULL,
   PRIMARY KEY(issuer,subject,email));
  CREATE INDEX IF NOT EXISTS oak_auth_verified_email_lookup ON oak_auth_verified_emails(email);
 `);
}
function createSuperAdminPolicy(db,configured){
 installAdminSchema(db);let emails=new Set(),configurationError='';
 function reload(next){try{emails=parseSuperAdminEmails(next);configurationError='';}catch{emails=new Set();configurationError='SUPER_ADMIN_EMAILS_INVALID';}}
 reload(configured);
 function remember(identity,now=Date.now()){
  if(!identity||typeof identity.issuer!=='string'||!identity.issuer||typeof identity.subject!=='string'||!identity.subject)throw new AuthError('INVALID_EXTERNAL_IDENTITY',401);
  const email=normalizeEmail(identity.email)||'',verified=identity.emailVerified===true&&!!email;
  db.prepare(`INSERT INTO oak_auth_identity_observations(issuer,subject,email,email_verified,last_seen) VALUES(?,?,?,?,?)
   ON CONFLICT(issuer,subject) DO UPDATE SET email=excluded.email,email_verified=excluded.email_verified,last_seen=excluded.last_seen`)
   .run(identity.issuer,identity.subject,email,verified?1:0,now);
  if(verified)db.prepare('INSERT OR IGNORE INTO oak_auth_verified_emails(issuer,subject,email) VALUES(?,?,?)').run(identity.issuer,identity.subject,email);
 }
 function canManage(issuer,subject){
  if(typeof issuer!=='string'||typeof subject!=='string')return false;
  const latest=db.prepare('SELECT email,email_verified FROM oak_auth_identity_observations WHERE issuer=? AND subject=?').get(issuer,subject);
  if(configurationError||!latest||latest.email_verified!==1||!emails.has(latest.email))return false;
  const owners=db.prepare('SELECT issuer,subject FROM oak_auth_verified_emails WHERE email=? LIMIT 2').all(latest.email);
  return owners.length===1&&owners[0].issuer===issuer&&owners[0].subject===subject;
 }
 function snapshot(issuer,subject){const row=db.prepare('SELECT email,email_verified,last_seen FROM oak_auth_identity_observations WHERE issuer=? AND subject=?').get(issuer,subject);return row?{email:row.email,emailVerified:row.email_verified===1,lastSeen:row.last_seen,superAdmin:canManage(issuer,subject),configurationError}:null;}
 function status(){return {configurationError,configuredCount:emails.size};}
 return {reload,remember,canManage,snapshot,status};
}
module.exports={normalizeEmail,parseSuperAdminEmails,createSuperAdminPolicy};
