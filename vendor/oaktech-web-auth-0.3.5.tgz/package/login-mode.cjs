'use strict';
const {AuthError,modeFromEnv}=require('./mode.cjs');
const MODES=new Set(['token','casdoor','builtin']);
function loginModeFromEnv(env=process.env,legacyDefault='casdoor'){
  if(env.APP_LOGIN_MODE!==undefined){
    if(env.APP_AUTH_MODE!==undefined||env.AUTH_MODE!==undefined)throw new AuthError('LOGIN_MODE_CONFLICT',503);
    if(!MODES.has(env.APP_LOGIN_MODE))throw new AuthError('LOGIN_MODE_INVALID',503);
    return env.APP_LOGIN_MODE;
  }
  if(env.APP_AUTH_MODE!==undefined||env.AUTH_MODE!==undefined)return modeFromEnv(env,legacyDefault==='token'?'local':legacyDefault);
  return legacyDefault;
}
function standardLoginConfigured(env=process.env){return env.APP_LOGIN_MODE!==undefined||env.APP_AUTH_MODE!==undefined;}
module.exports={loginModeFromEnv,standardLoginConfigured};
