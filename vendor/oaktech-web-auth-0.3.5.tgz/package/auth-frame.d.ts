import type {ReactElement, ReactNode} from 'react';
export interface AuthFrameProps {
  appName: string;
  title: string;
  description?: string;
  children?: ReactNode;
  settingsHref?: string;
  portalHref?: string;
  actions?: Array<{href:string; label:string; primary?:boolean}>;
}
export function AuthFrame(props:AuthFrameProps):ReactElement;
